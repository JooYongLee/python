from PyQt5 import Qt
from PyQt5 import QtCore
from PyQt5 import QtGui
import json
import time
import numpy as np
import sys
import vtk
import os
from vtk.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor

from common import get_runtime_logger

import qtutils
from qtutils import create_action
from guideline import GuideROI
import datadoc
import vtk_utils
from QProgressIndicator import External, QProgressIndicator
from xrayviewer import XrayViewer
from slicer import ImageSlicer
from typing import Dict, List, Tuple, Union

from Marker import Marker

CORONAL = 0
AXIAL = 1
SAGITTAL = 2
VIEW_NAMES = [
    "CORONAL",
    "AXIAL",
    "SAGITTAL",
]

MAR         = 'MAR'
NORMAL      = 'NORMAL'
NONMETAL    = 'NONMETAL'
NONE        = 'NONE'

DATA_SET_CLASS = [
    MAR,
    NORMAL,
    NONMETAL,
    NONE
]

SHORTCUT_KEY = [
    'q',
    'w',
    'e',
    'r'
]

CLASS_DESCRIPT = [
    'metal-artifact',
    'normal',
    'none-metal, medium',
    'none'
]

COLOR_TABLE = {
    MAR: Qt.QColor(255, 0, 0),
    NORMAL: Qt.QColor(0, 255, 0),
    NONMETAL: Qt.QColor(255, 255, 0),
    NONE: Qt.QColor(245, 245, 255),
}


class ToothStatus(object):
    def __init__(self, tau=-1, metal_artifact=False):
        self.num = tau
        self.metal_artifact = metal_artifact

    def __repr__(self):
        return "number : {} metal-artifact:{}".format(self.num,
                                                      self.metal_artifact)


class DataSet(object):
    def __init__(self, size:int):
        self.img_class = [NONE] * size

    def save(self, selected:List[int], type:str):
        for num in selected:
            self.img_class[num] = type


class CoordinateInfo(object):
    def __init__(self, view_name:str, x:int, y:int, slice_num:int):
        self.view_name = view_name
        self.x = x
        self.y = y
        self.slice_num = slice_num

    def __repr__(self):
        msg = "[view:{} / ({},{})]".format(self.view_name, self.x, self.y)
        return msg

class MarkersInfo(object):
    def __init__(self, view_name: str, pose:[0,0], slicenum_num:int):
        self.view_name = view_name
        self.pose = pose
        self.slicenum_num = slicenum_num

class NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(NpEncoder, self).default(obj)

# QtGui.QTre
class TreeItemWidget(Qt.QTreeWidget):
    def __init__(self, *args, **kwargs):
        super(TreeItemWidget, self).__init__()
        for each in ['MAE', 'Test']:
            item = Qt.QTreeWidgetItem()
            item.setText(0, each)
            self.addTopLevelItem(item)

            comboBox = Qt.QComboBox()
            comboBox.addItem("None")
            comboBox.addItem("Metal")
            comboBox.currentTextChanged.connect(self.changeText)

            lineEdit = Qt.QLineEdit()
            self.setItemWidget(item, 1, comboBox)
            self.setItemWidget(item, 2, lineEdit)
            # comboBox.mousePressEvent = partial(self.mousePressEventChild, currentQTreeWidgetItem = item, child = comboBox)
            # lineEdit.mousePressEvent = partial(self.mousePressEventChild, currentQTreeWidgetItem = item, child = lineEdit)
        self.setColumnCount(3)
        self.resize(360,240)
        # current selected items
        self.stat_items = ToothStatus(0)


        self.tooth_stat_items = {}
        self.__init_stat_items()

    def __init_stat_items(self):
        self.tooth_stat_items.clear()
        for i in range(1, 5):
            for j in range(1, 9):
                tau = i * 10 + j
                tau = str(tau)
                self.tooth_stat_items[tau] = ToothStatus(tau)

    def update_stat(self):
        # for it in self.items():
        it = self.topLevelItem(0)
        if isinstance(it, Qt.QTreeWidgetItem):
            if it.text(0) == "MAE":
                combo = self.itemWidget(it, 1)
                index = int(self.stat_items.metal_artifact)
                combo.setCurrentIndex(index)

    def setItems(self, number:int):
        number = str(number)
        item = self.tooth_stat_items[number]
        self.stat_items = item
        #self.itemAt()
        # self.show()
    def changeText(self):
        # lambda x: x == "Metal"
        for it in self.selectedItems():
            if isinstance(it, Qt.QTreeWidgetItem):
                combo = self.itemWidget(it, 1)
                print("{}:{}".format(it.text(0), combo.currentText()))
                self.stat_items.metal_artifact = combo.currentText() == "Metal"

    def load_item(self, filename:str):
        """
        items : path-name for data
        """
        if os.path.exists(filename):
            items = read_tooth_stat(filename)
            self.tooth_stat_items.clear()
            for k, v in items.items():
                stat = ToothStatus()
                stat.__dict__.update(**v)
                self.tooth_stat_items[k] = stat
        else:
            self.__init_stat_items()



    def write_item(self, filename):
        write_tooth_stat(filename, self.tooth_stat_items)


def write_tooth_stat(filename, items:dict):
    # np.testing.
    check = [isinstance(it,ToothStatus) for it in items.values()]
    assert np.all(check)
    dict_items = {k:v.__dict__ for k, v in items.items()}
    with open(filename, "w") as f:

        json.dump(dict_items, f, indent='\t')

def read_tooth_stat(filename):
    items = {}
    if os.path.exists(filename):
        with open(filename, "r") as f:
            items = json.load(f)
    return items



def _apply_mask(image, mask, color, alpha=0.5):
    """Apply the given mask to the image.
    """
    for c in range(3):
        image[:, :, c] = np.where(mask > 0,
                                  image[:, :, c] *
                                  (1 - alpha) + alpha * color[c] * 255,
                                  image[:, :, c])
    return image

def blending_mask(image, mask, alpha=0.5):
    for c in range(3):
        image[:, :, c] = np.where(mask[:, :, c] > 0,
                                  image[:, :, c] *
                                  (1 - alpha) + alpha * mask[:, :, c],
                                  image[:, :, c])
    return image

class ToothListWidget(Qt.QListWidget):
    def __init__(self):
        super(ToothListWidget, self).__init__()

        self.setSelectionMode(Qt.QAbstractItemView.ExtendedSelection)
        self.setMaximumWidth(100)
        for i in range(1, 5):
            for j in range(1, 9):
                tau = i*10 + j
                self.addItem(str(tau))

class DataListWidget(Qt.QListWidget):
    def __init__(self):
        super(DataListWidget, self).__init__()

        self.setSelectionMode(Qt.QAbstractItemView.ExtendedSelection)
        self.setMaximumWidth(100)

    def update_data_list(self):
        doc = datadoc.get_document()
        self.clear()
        # for db_blob in doc.imgdb.volume_img:
        #     workname = os.path.basename(os.path.dirname(db_blob._source_directory))
        #     self.addItem(workname)

class Renderer(QVTKRenderWindowInteractor):
    def __init__(self):
        super(Renderer, self).__init__()
        # self.test_actor = vtk.vtkActor()
        self.iren = self.GetRenderWindow().GetInteractor()
        self.ren = vtk.vtkRenderer()

        # self.ren.AddActor(self.test_actor)
        self.iren.GetRenderWindow().AddRenderer(self.ren)

        self.boxes_list = []
        self.iren.Initialize()
        self.iren.AddObserver("KeyPressEvent", self.keypress_event)
        self.iren.Start()

    def add(self, actor, focal_point=None):
        self.ren.AddActor(actor)
        if focal_point is not None:
            self.ren.GetActiveCamera().SetFocalPoint(*focal_point)
        self.GetRenderWindow().Render()

    def keypress_event(self, obj, event):
        key = obj.GetKeySym()
        # print(key)
        if key == "o":
            for v in self.ren.GetViewProps():
                if isinstance(v, vtk.vtkVolume):
                    v.SetVisibility(not v.GetVisibility())
        elif key == "c":
            self.write_image()


        self.iren.Render()

    def write_image(self):
        obj = self.iren
        save_dir = "test_image"
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)

        imagefilter = vtk.vtkWindowToImageFilter()

        imagefilter.SetInput(obj.GetRenderWindow())
        # imagefilter.SetM
        imagefilter.ReadFrontBufferOff()
        imagefilter.SetInputBufferTypeToRGBA()
        imagefilter.Update()

        lt = time.localtime()

        str_time = "{}{}{}".format(lt.tm_hour, lt.tm_min, lt.tm_sec)

        writer = vtk.vtkPNGWriter()
        writer.SetFileName("test_image/{}.png".format(str_time))
        writer.SetInputConnection(imagefilter.GetOutputPort())
        writer.Write()

        obj.GetRenderWindow().GetRenderers().GetFirstRenderer().ResetCamera()
        obj.Render()


    def all_clear_items(self):
        for it in self.ren.GetViewProps():
            if isinstance(it, vtk.vtkActor):
                self.ren.RemoveActor(it)
            elif isinstance(it, vtk.vtkVolume):
                self.ren.RemoveVolume(it)
            else:
                self.ren.RemoveActor(it)

    # def refresh_current_tooth_image(self, num):
    #     self.iren.Render()
    #     # doc = datadoc.get_document()
    #     # convert_vtkvolume
    #     pass

    def update_image(self):

        self.all_clear_items()
        doc = datadoc.get_document()
        for a in doc.viewprops.values():
            if isinstance(a, vtk.vtkActor):
                self.ren.AddActor(a)
            elif isinstance(a, vtk.vtkVolume):
                self.ren.AddVolume(a)
            else:
                self.ren.AddActor(a)
        # change view-point
        cam = self.ren.GetActiveCamera()
        bounds = doc.volume_vtk.GetBounds()
        ctr = doc.volume_vtk.GetCenter()
        pos = [ctr[0], ctr[1], ctr[2]]

        pos[1] = pos[1] + bounds[1]*3
        cam.SetViewUp(0, 0, -1)
        cam.SetPosition(*pos)
        cam.SetFocalPoint(*ctr)

        self.iren.Render()



    def clear_boxes(self):
        for a in self.ren.GetActors():
            if a in self.boxes_list:
                self.ren.RemoveActor(a)
                self.boxes_list.remove(a)

    def add_boxes(self, box:vtk.vtkActor):
        self.ren.AddActor(box)
        self.boxes_list.append(box)

    def selection_update(self, numbers):
        """
        :param numbers: list of integer
        :return:
        """
        self.clear_boxes()
        if numbers:
            denorm_boxes = None
            doc = datadoc.get_document()
            colortable = doc.get_color_table()
            for num in numbers:
                boxes = doc.get_bbox(num)
                if boxes is not None:
                    denorm_boxes = datadoc.denorm_boxes(boxes, doc.volume_img.shape)

                    boxes_vtk = np.empty_like(denorm_boxes)
                    # # (x1, x2, y1, y2, z1, z2)
                    boxes_vtk[::2] = denorm_boxes[:3][::-1]
                    boxes_vtk[1::2] = denorm_boxes[3:][::-1]

                    b = vtk_utils.get_cube(boxes_vtk)
                    b.GetProperty().SetColor(*colortable[num])
                    self.add_boxes(b)

            if denorm_boxes is not None:
                # last elements camera update
                ctr = (denorm_boxes[:3] + denorm_boxes[3:])/2
                cam = self.ren.GetActiveCamera()
                cam.SetFocalPoint(*ctr[::-1])

            self.iren.Render()

    def draw_cube_from_voi(self, voi):
        NotImplemented


class ImageWidget(Qt.QGraphicsScene):
    update_voi_signal = Qt.pyqtSignal() # not used
    focus_changed_signal = Qt.pyqtSignal() # focus
    boundary_changed_signal = Qt.pyqtSignal()

    def __init__(self, mode, list_slicer:ImageSlicer):
        assert mode in [CORONAL, AXIAL, SAGITTAL]
        super(ImageWidget, self).__init__()
        self.list_widget = list_slicer
        self.drawing_mask = False

        self.name = VIEW_NAMES[mode]
        self.mode = mode
        self.viewWidget = Qt.QGraphicsView()
        self.viewWidget.setScene(self)

        # mouseMove 이벤트 On?
        self.viewWidget.setMouseTracking(True)

        # 이미지 시작시 초기화할 해상도 크기 설정
        # empty = np.zeros([300, 300, 3], dtype=np.uint8)
        empty = np.ones([300, 300, 3], dtype=np.uint8) * 255

        # 이미지 추가
        self.pixmap = Qt.QGraphicsPixmapItem()
        self.pixmap.setPixmap(Qt.QPixmap(qtutils.numpy2qimage(empty)))
        self.addItem(self.pixmap)

        # bounding-box(red)
        self.x_min = GuideROI(mode=Qt.Qt.Horizontal)
        self.x_max = GuideROI(mode=Qt.Qt.Horizontal)
        self.y_min = GuideROI(mode=Qt.Qt.Vertical)
        self.y_max = GuideROI(mode=Qt.Qt.Vertical)

        # focus-line
        self.focus_x = GuideROI(mode=Qt.Qt.Horizontal)
        self.focus_y = GuideROI(mode=Qt.Qt.Vertical)

        # default_pen.setDashPattern(dashes)
        self.focus_x.change_pen()
        self.focus_y.change_pen()

        # item 추가
        self.addItem(self.x_min)
        self.addItem(self.x_max)
        self.addItem(self.y_min)
        self.addItem(self.y_max)

        self.addItem(self.focus_x)
        self.addItem(self.focus_y)

        # to select item
        self._current_item = None

        self.reset_guideline()
        self.reset_focus()

        self.markers = []
        self.picking_markers = None

        self.slicenum_image = 0

    def add_mark(self, pose):
        marker = Marker(self, pose)
        self.addItem(marker)

    def delete_mark(self, item):
        if isinstance(item, Marker):
             self.removeItem(item)
             print("marker", item)
        else:
            pass

    def delete_all_mark(self):
        for item in self.items():
            self.delete_mark(item)

    def load_mark_from_document(self):
        # 1. get document
        doc = datadoc.get_document()
        # doc.picking_markers
        maxMarkerNum = len(doc.picking_markers)
        slicenum = self.slicenum_image
        view_name = self.name
        print("view_name", view_name)
        # 2. mode check & slice 번호 모드 체크해서. 해당되는 (2d) 3d 좌표 가져온다.
        # 4. add
        for i in range(0, len(doc.picking_markers)):
            if doc.picking_markers[i].view_name == view_name and doc.picking_markers[i].slicenum_num == slicenum:
                self.addItem(doc.picking_markers[i])
            else:
                pass

        # FIXME : for init test
    def reset_focus(self):
        self.draw_focus_line()

    def draw_focus_line(self):
        # print(self.sender())
        bounding = self.pixmap.sceneBoundingRect()

        img_x0 = bounding.x()
        img_y0 = bounding.y()
        width = bounding.width()
        height = bounding.height()

        doc = datadoc.get_document()
        focus_center = doc.get_current_focus()
        # focus 좌표계(z,y,x)
        pose = self._change_coordinate_w2d(focus_center)
        y, x = pose

        self.focus_x.setLine(img_x0, y, img_x0 + width, y)
        self.focus_x.setMinMax(img_y0, img_y0 + height)

        self.focus_y.setLine(x, img_y0, x, img_y0 + height)
        self.focus_y.setMinMax(img_x0, img_x0 + width)

        # drawing update
        self.draw_plane_image()

    def draw_plane_image(self):
        """
        document 에 저장한 focus 좌표를 읽어와서
        각 viewer plane-image 갱신
        """
        pass
        doc = datadoc.get_document()
        focus_center = doc.get_current_focus()
        # pose = self.change_focus_d2w(focus_center)
        dhw = np.array(doc.volume_img.shape) - 1
        inds = np.round(dhw * focus_center).astype(np.int32)
        color_mask = doc.color_volume_mask
        if self.mode == CORONAL:
            pose = inds[1]
            img = doc.volume_img[:, pose, :]
            mask = color_mask[:, pose, :]
        elif self.mode == AXIAL:
            pose = inds[0]
            img = doc.volume_img[pose, :, :]
            mask = color_mask[pose, :, :]
        elif self.mode == SAGITTAL:
            pose = inds[2]
            img = doc.volume_img[:, :, pose]
            mask = color_mask[:, :, pose]
        self.slicenum_image = pose

        #
        img = np.repeat(np.expand_dims(img, axis=-1), 3, 2)
        # import utils
        if self.drawing_mask:
            img = blending_mask(img.copy(), mask.copy())
        # import cv2
        # 이미지 갱신
        self.pixmap.setPixmap(Qt.QPixmap(qtutils.numpy2qimage(img)))

        # market 관련 갱신
        self.delete_all_mark()
        self.load_mark_from_document()

    def get_boundary_boxes(self):
        y1 = self.x_min.line().y1()
        y2 = self.x_max.line().y2()
        x1 = self.y_min.line().x1()
        x2 = self.y_max.line().x2()
        p1 = np.array([y1, x1])
        p2 = np.array([y2, x2])
        # print(p1, p2)

        w1 = self.convert_d2w(p1)
        # print(p1,"----->", w1)
        w2 = self.convert_d2w(p2)

        return np.concatenate([w1, w2])

    def _change_coordinate_w2d(self, pose):
        """
        vtk 공간 좌표계 연동(world)좌표계를 각 viewer 이미지 좌표계로 변경
        :param pose: [3], normalize 0 ~ 1
        :return: (y, x) in display
        """
        def _denorm_bounds(inpose, shape):
            inpose = np.asarray(inpose)
            shape = np.asarray(shape)
            return inpose * (shape-1.)
        bounding = self.pixmap.sceneBoundingRect()
        pose = np.asarray(pose)
        x1 = bounding.x()
        y1 = bounding.y()
        ws = bounding.width()
        hs = bounding.height()
        shift = np.asarray([y1, x1])

        if self.mode == CORONAL:
            ps = pose[[0, 2]]
        elif self.mode == AXIAL:
            ps = pose[[1, 2]]
        elif self.mode == SAGITTAL:
            ps = pose[[0, 1]]
        ps = _denorm_bounds(ps, (hs, ws))
        ps = ps + shift
        return ps

    def convert_d2w(self, pose):
        """
        viewer 이미지 좌표계를 world 좌표계로 변경
        :param pose: 2 tuple, (u, v)
        :return: 3 tuple (z, y, x)
        """
        def _norm_bounds(inpose, shape):
            inpose = np.asarray(inpose)
            shape = np.asarray(shape)
            return inpose / (shape-1.)

        bounding = self.pixmap.sceneBoundingRect()
        pose = np.asarray(pose)

        x1 = bounding.x()
        y1 = bounding.y()
        ws = bounding.width()
        hs = bounding.height()
        xs = pose[1] - x1
        ys = pose[0] - y1
        norm_xy = _norm_bounds((ys, xs), (hs, ws))
        y, x = norm_xy

        doc = datadoc.get_document()
        focus_center = doc.get_current_focus().copy()

        if self.mode == CORONAL:
            focus_center[0] = y
            focus_center[2] = x

        elif self.mode == AXIAL:
            focus_center[1] = y
            focus_center[2] = x

        elif self.mode == SAGITTAL:
            focus_center[0] = y
            focus_center[1] = x
        return focus_center

    def change_focus_d2w(self, pose):
        focus_center = self.convert_d2w(pose)
        doc = datadoc.get_document()
        doc.change_focus(focus_center)
        return focus_center

    def reset_guideline(self):

        bounding = self.pixmap.sceneBoundingRect()

        img_x0 = bounding.x()
        img_y0 = bounding.y()
        width = bounding.width()
        height = bounding.height()

        self.x_min.setLine(img_x0, img_y0, img_x0 + width, img_y0)
        self.x_min.setMinMax(img_y0, img_y0 + height)

        self.x_max.setLine(img_x0, img_y0 + height, img_x0 + width, img_y0 + height)
        self.x_max.setMinMax(img_y0, img_y0 + height)

        self.y_min.setLine(img_x0, img_y0, img_x0, img_y0 + height)
        self.y_min.setMinMax(img_x0, img_x0 + width)

        self.y_max.setLine(img_x0 + width, img_y0, img_x0 + width, img_y0 + height)
        self.y_max.setMinMax(img_x0, img_x0 + width)


    def _get_pick_items(self, curPt:Qt.QPointF):
        """
        picking 한 아이템이 있는지 체크.
        마우스 picking좌표와 모든 아이템 좌표의 거리를 계산해서 특정 거리안의, 가장 가까운 아이템을 반환
        없을 경우는 None
        1. picking 안에 아이템이 있는지 확인
        2. 피킹 아이템이 있을 경우 내부 변수 '_current_item'에 피킹 아이템 저장
        3. 피킹 아이템 반환

        """
        # print(curPt.y(), self.axial_x_min.line().y1())
        thresh_dist = 10
        self._current_item = None

        check_x_item_list = [
            self.x_min,
            self.x_max,
            self.focus_x
        ]

        check_y_item_list = [
            self.y_min,
            self.y_max,
            self.focus_y
        ]

        for item in check_x_item_list:
            x1 = item.line().x1()
            x2 = item.line().x2()
            line_y = item.line().y1()

            if np.abs(curPt.y() - line_y) <= thresh_dist and\
                x1 <= curPt.x() <= x2:
                self._current_item = item

        for item in check_y_item_list:
            y1 = item.line().y1()
            y2 = item.line().y2()

            line_x = item.line().x1()

            if np.abs(curPt.x() - line_x) <= thresh_dist and\
                y1 <= curPt.y() <= y2:
                self._current_item = item
        return self._current_item


    def _get_current_item(self):
        return self._current_item

    def focusInEvent(self, event: QtGui.QFocusEvent) -> None:
        print(self.name, 'changed focus')
        doc = datadoc.get_document()
        doc.focus_view = self.name
        doc.change_focus(doc.get_current_focus())

    def mousePressEvent(self, event: QtGui.QMouseEvent):
        # update current view
        doc = datadoc.get_document()
        curPt = event.scenePos()
        logger = get_runtime_logger()
        if not self.pixmap.sceneBoundingRect().contains(curPt):
            logger.info('out of image')
            return

        view_name = self.name
        slicenum_num = self.slicenum_image


        item = self.itemAt(event.scenePos(), Qt.QTransform())

        if event.button() == QtCore.Qt.LeftButton:
            pose = [event.scenePos().x(), event.scenePos().y()]
            marker = Marker(pose=pose, slicenum_num=slicenum_num, view_name=view_name)
            logger.debug('pose:{}/slice:{}:view:{}'.format(pose, slicenum_num, view_name))


            # picking marker check
            if isinstance(item, Marker):
                index_num = doc.picking_markers.index(item)
                self.picking_markers = doc.picking_markers[index_num]
                print("isinstance item", self.picking_markers)
                # self.picking_markers = item
            else:
                self.markers.append(marker)
                self.addItem(marker)
                # 임시로 색상 추가
                self.list_widget.setColorAtItem(slicenum_num, Qt.QColor(255, 0, 0))
                print("삭제전", self.markers)
                doc.picking_markers.append(marker)
                print("생성", len(doc.picking_markers))

        elif event.button() == QtCore.Qt.RightButton:
            if isinstance(item, Marker):
                self.removeItem(item)
                self.markers.remove(item)
                print("삭제후", self.markers)
                print("marker information", item)
                index_num = doc.picking_markers.index(item)
                doc.picking_markers.pop(index_num)
                print("제거 후", len(doc.picking_markers))
                # 임시로 색상 초기화
                self.list_widget.setColorAtItem(self.slicenum_image, Qt.QColor(255, 255, 255))
        else:
            pass

        current_item = self._get_pick_items(curPt)
        if current_item is None:
            return
        # mouse prses일때 picking 한 아이템이 있을 경우 selectio Mode On(release 일때 해제)
        current_item.change_selected_mode(True)

    def mouseMoveEvent(self, event: 'QGraphicsSceneMouseEvent'):
        if self._current_item is not None:

            if self._current_item.mode == Qt.Qt.Horizontal:
                value = event.scenePos().y()
            else:
                value = event.scenePos().x()

            # picking 한 라인 이동 처리
            self._current_item.move_the_line(value)

            # 현재 picking 라인 하나만 선택되므로, 나머지 line도 이동 처리해준다.
            if self._current_item in [self.focus_x, self.focus_y]:
                # print("change focus")
                # picking 아이템이 focus_x일때는 focus_y를 처리. 아닐 경우는 그 반대
                if self._current_item == self.focus_x:
                    self.focus_y.move_the_line(event.scenePos().x())
                else:
                    self.focus_x.move_the_line(event.scenePos().y())

                y = self.focus_x.line().y1()
                x = self.focus_y.line().x1()
                # 이미지 좌표계 변경 및 document에 저장
                self.change_focus_d2w((y, x))
                # (0~1) 정규화된 좌표, (Depth X Height X width)
                doc = datadoc.get_document()
                focus_zyx_norm = datadoc.get_document().focus_center
                pose = focus_zyx_norm * (np.array(doc.volume_img.shape) - 1)
                print(pose)

                # 각 view 마다 slice 번호가 달라서 pose에서 설정
                if self.name == "AXIAL":
                    slice_num = pose[0]
                elif self.name == "CORONAL":
                    slice_num = pose[1]
                else:
                    slice_num = pose[2]

                view_name = self.name
                x = int(x)
                y = int(y)
                slice_num = int(slice_num)

                CoordinateInfo(view_name, x, y, slice_num)
                coorinfo = CoordinateInfo(view_name, x, y, slice_num)
                # doc.coordinate_information.append(coorinfo) # slice_num은 넘어 오지 않음
                doc.coordinate_information.append(coorinfo.__dict__)
                print("Coorinfomation", coorinfo.__dict__)

                # 변경 signal emit
                self.focus_changed_signal.emit()

            elif self._current_item in [self.x_min, self.x_max, self.y_min, self.y_max]:
                # other draw x, y
                if self._current_item in [self.x_min, self.x_max]:
                    assert isinstance(self._current_item, GuideROI) or True
                    # current item y1, y2
                    shift_y = self._current_item.line().y1()

                    x1 = self.y_min.line().x1()
                    x2 = self.y_max.line().x2()

                    if self._current_item == self.x_min:
                        y = self.y_min.line().y2()
                        self.y_min.setLine(x1, shift_y, x1, y)
                        self.y_max.setLine(x2, shift_y, x2, y)
                    elif self._current_item == self.x_max:
                        y = self.y_min.line().y1()
                        self.y_min.setLine(x1, y, x1, shift_y)
                        self.y_max.setLine(x2, y, x2, shift_y)
                    # shift_pose = (shift_y, x1)
                    # shift_pose = self.convert_d2w(shift_pose)
                    # doc = datadoc.get_document()
                    # doc.get_bbox(num)
                else:
                    shift_x = self._current_item.line().x1()

                    y1 = self.x_min.line().y1()
                    y2 = self.x_max.line().y2()

                    if self._current_item == self.y_min:
                        x = self.x_min.line().x2()
                        self.x_min.setLine(shift_x, y1, x, y1)
                        self.x_max.setLine(shift_x, y2, x, y2)
                    elif self._current_item == self.y_max:
                        x = self.x_min.line().x1()
                        self.x_min.setLine(x, y1, shift_x, y1)
                        self.x_max.setLine(x, y2, shift_x, y2)

                    # boundary_changed_signal = Qt.pyqtSignal()

                self.boundary_changed_signal.emit()
                # signal emit

                pass



            self._update_other_roi()

            # TODO:signal emit

        # marker move
        if self.picking_markers is not None:
            self.picking_markers.updatePose(pose=[event.scenePos().x(), event.scenePos().y()])
            print("click pose", self.picking_markers)
            doc = datadoc.get_document()
            print("change pose", doc.picking_markers)


    def mouseReleaseEvent(self, event: 'QGraphicsSceneMouseEvent'):
        item = self._get_current_item()
        # print(item)

        if item is not None:
            # mouse Release 이벤트에 selection Mode Off
            self._current_item.change_selected_mode(False)
            # 현재 활성화 아이템 해제
            self._current_item = None
        else:
            pass

        # marker move 해제
        if self.picking_markers is not None:
            self.picking_markers = None
        else:
            pass

    def _update_other_roi(self):
        # TODO:update other roi, synchronziation
        if self._current_item is not None:
            value = self._current_item.get_pos()
        # if self._current_item == self.axial_y_min:
        #     self.coronal_y_min.set_pos(value)
        # elif self._current_item == self.axial_y_max:
        #     self.coronal_y_max.set_pos(value)
        # elif self._current_item == self.coronal_y_min:
        #     self.axial_y_min.set_pos(value)
        # elif self._current_item == self.coronal_y_max:
        #     self.axial_y_max.set_pos(value)
        # else:
        #     pass

    def update_image(self):
        self.draw_plane_image()
        # self.draw_boundary_box(11)

    def draw_boundary_box(self, num):
        doc = datadoc.get_document()
        bbox = doc.get_bbox(num)
        if bbox is None:
            return
        color_table = get_teeth_color_table()

        for line in [self.x_min, self.x_max, self.y_min, self.y_max]:
            num_10 = num % 10
            color = color_table[num_10]
            line.change_default_pen(color)

        p1 = self._change_coordinate_w2d(bbox[:3])
        p2 = self._change_coordinate_w2d(bbox[3:])
        # print(p1, p2, "draw_boundingbox")
        y1, x1 = p1
        y2, x2 = p2

        bounding = self.pixmap.sceneBoundingRect()

        img_x0 = bounding.x()
        img_y0 = bounding.y()
        width = bounding.width()
        height = bounding.height()

        self.x_min.setMinMax(img_y0, img_y0 + height)
        self.x_max.setMinMax(img_y0, img_y0 + height)
        self.y_min.setMinMax(img_x0, img_x0 + width)
        self.y_max.setMinMax(img_x0, img_x0 + width)

        self.x_min.setLine(x1, y1, x2, y1)
        self.x_max.setLine(x1, y2, x2, y2)
        self.y_min.setLine(x1, y1, x1, y2)
        self.y_max.setLine(x2, y1, x2, y2)

    def selection_update(self, num):
        self.draw_focus_line()
        self.draw_boundary_box(num)



class MainWindow(Qt.QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()

        self.mainmenu = self.menuBar()

        self.work_dirname = ''

        self.tabWidget =  Qt.QTabWidget()
        # self.tabWidget = Qt.QStackedWidget()
        # self.tab01 = Qt.QWidget()
        self.tab01 = Qt.QWidget()
        self.tab02 = Qt.QWidget()

        self.tabWidget.addTab(self.tab01, "cbct")
        self.tabWidget.addTab(self.tab02, "X-Ray")
        # self.tabWidget.addWidget(self.tab02)
        # self.tabWidget.addTab()

        tablayout = Qt.QVBoxLayout()
        tablayout.addWidget(self.tabWidget)


        self.libraryEditor = MarClassifier(self, self.tab01)
        self.xrayViewer = XrayViewer(self, self.tab02)
        self.setAcceptDrops(True)
        self.frame = Qt.QFrame()
        self.frame.setLayout(tablayout)
        self.setCentralWidget(self.frame)
        self.showMaximized()
        self.show()

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            print('dragEnterEvent in accept')
            event.accept()
        else:
            print('dragEnterEvent in ignore')
            event.ignore()
    #
    # def dropEvent(self, event):
    #     files = [u.toLocalFile() for u in event.mimeData().urls()]
    #     for f in files:
    #         print(f)


class MarClassifier(Qt.QMainWindow):
    def __init__(self, parent, tab=None):
        super(MarClassifier, self).__init__(parent)
        # Qt.QMainWindow.__init__(self, parent)

        self.logger = get_runtime_logger()
        self.mainmenu = self.menuBar()

        self.work_dirname = ''

        openAct = create_action('&Open', "", "Ctrl+O", "Open File", self, self.open_file)
        saveAct = create_action("&Save", "", "", "Save File", self, self.save_file)

        updateItemAct = create_action("&Update", "", "", "Update Current Item", self, self.update_current_items)
        editFinishgedAct = create_action("&Apply", "", "", "Apply Auto refinement Mask", self, self.apply_auto_refinement_mask)
        pickle2itkconvert = create_action("&Convert", "", "", "Convert from pickle to itk files", self, self.convert_pickle_file)

        saveDataAct = create_action('SAVE', '', 'Ctrl+S', 'Save json', self, self.save_data)
        temSaveAct = create_action('template SAVE', '', '', 'Save json', self, self.template_save_data)

        swith_maskAct = create_action("&Swith Mask", "", "Alt+O", "Switch Segmentation mask on/off", self,self.switch_mask)
        swith_maskAct.setData(True)
        self.swith_maskAct = swith_maskAct

        filemenu = self.mainmenu.addMenu("&File")
        filemenu.addAction(openAct)
        filemenu.addAction(saveAct)

        editmenu = self.mainmenu.addMenu("&Edit")
        editmenu.addAction(editFinishgedAct)
        editmenu.addAction(updateItemAct)
        editmenu.addAction(pickle2itkconvert)
        editmenu.addAction(swith_maskAct)

        # savemenu 생성
        # save : 기존 save , template save : 좌표 저장하는 save
        savemenu = self.mainmenu.addMenu("&Save")
        savemenu.addAction(saveDataAct)
        savemenu.addAction(temSaveAct)

        self.mainmenu.addAction(create_action('IMPORT', '', 'Ctrl+I', 'Import json', self, self.import_data))
        
        default_slicer = 100        
        # axial 방향의 slice image index 관리
        self.image_slicer = ImageSlicer()
        self.image_slicer.reset_items(default_slicer)
        # AXIAL, SAGITTAL, CORONAL 3개 뷰로 이미지위젯 그리
        self.imgwidget1 = ImageWidget(AXIAL, self.image_slicer)
        self.imgwidget2 = ImageWidget(SAGITTAL, self.image_slicer)
        self.imgwidget3 = ImageWidget(CORONAL, self.image_slicer)

        # focus 라인이 변경되면 나머지 두개의 view에서 focus 라인 연동처리해준다.
        self.imgwidget1.focus_changed_signal.connect(self.imgwidget2.draw_focus_line)
        self.imgwidget1.focus_changed_signal.connect(self.imgwidget3.draw_focus_line)

        self.imgwidget2.focus_changed_signal.connect(self.imgwidget1.draw_focus_line)
        self.imgwidget2.focus_changed_signal.connect(self.imgwidget3.draw_focus_line)

        self.imgwidget3.focus_changed_signal.connect(self.imgwidget1.draw_focus_line)
        self.imgwidget3.focus_changed_signal.connect(self.imgwidget2.draw_focus_line)

        # 마찬가지로 bounding-box(roi) 용 박스가 변경될때 렌더러(vtk) box 갱신. mar-editor에서는 사용하지 않는다.
        self.imgwidget1.boundary_changed_signal.connect(self.change_bbox)
        self.imgwidget2.boundary_changed_signal.connect(self.change_bbox)
        self.imgwidget3.boundary_changed_signal.connect(self.change_bbox)


        # 좌표 저장할 버튼
        coor_btn = Qt.QPushButton('Coordinate', self)
        coor_btn.clicked.connect(self.coordinate_button_clicked)

        # loadComleteSignal.
        # doc =

        toolbar = Qt.QToolBar()
        toolbar.setOrientation(Qt.Qt.Vertical)
        # toolbar.addAction(create_action("clear box", "", "clrtl+b", "clear bbox", self, self.clear_current_bbox))
        for i, cls in enumerate(DATA_SET_CLASS):
            toolbar.addAction(create_action(cls, "", "ctrl+" + SHORTCUT_KEY[i], CLASS_DESCRIPT[i], self, self.set_slice_type))
            # toolbar.addAction(create_action("MAR", "", "clrtl+a", "mar class", self, self.set_slice_type))
            # toolbar.addAction(create_action("NORMAL", "", "clrtl+b", "normal class", self, self.set_slice_type))
            # toolbar.addAction(create_action("NONE", "", "clrtl+b", "normal class", self, self.set_slice_type))


        # self.image_slicer.remove_items()
        self.renderer = Renderer()
        self.tooth_list_widget = ToothListWidget()
        self.data_list_widget = DataListWidget()
        self.tooth_items_widget = TreeItemWidget()
        # self.tooth_list_widget.Mul
        self.layout = Qt.QGridLayout()
        self.layout.addWidget(toolbar, 0, 0, 1, 1)
        self.layout.addWidget(coor_btn, 1, 0, 1, 1)
        self.layout.addWidget(self.renderer, 0, 1, 1, 1)
        self.layout.addWidget(self.imgwidget1.viewWidget, 0, 2, 1, 1)
        self.layout.addWidget(self.imgwidget2.viewWidget, 1, 1, 1, 1)
        self.layout.addWidget(self.imgwidget3.viewWidget, 1, 2, 1, 1)
        # self.layout.addWidget(self.list_info, 0, 3, 1, 1)
        self.layout.addWidget(self.tooth_list_widget, 0, 3, 2, 1)
        # self.layout.addWidget(self.data_list_widget, 0, 4, 2, 1)
        # self.layout.addWidget(self.tooth_items_widget, 0, 4, 2, 1)
        # self.layout.addWidget(self.list_info, 0, 4, 1, 1)
        self.layout.addWidget(self.image_slicer, 0, 4, 2, 1)

        # axis 파일 변경시 slice 변경하는 메소드 연결
        self.image_slicer.itemSelectionChanged.connect(self.slice_changed)

        # self.image_slicer.itemSelectionChanged()
        # self.image_slicer.selectionChanged()
        self.progress = QProgressIndicator(None)
        self.progress.setAnimationDelay(70)
        # self.progress = Qt.QProgressDialog("Operation in progress.", "Cancel", 0, 100)
        self.tooth_list_widget.itemClicked.connect(self.selection_update)
        # self.tooth_list_widget.currentItemChanged.connect()
        self.tooth_list_widget.itemSelectionChanged.connect(self.selection_update)
        self.data_list_widget.itemSelectionChanged.connect(self.change_db_item)


        doc = datadoc.get_document()


        # super(DataDoc, doc).__init__(self)

        doc.auto_refinement.connect(self.refresh_current_tooth_image)
        doc.focus_change_signal.connect(self.update_status_bar)
        # doc.loadComleteSignal.connect(self.data_load_test)
        # doc.loadComleteSignal.connect(self.update_viewer)
        self.statusBar = Qt.QStatusBar()
        # self.statusBar.showMessage("test show me the money")
        self.setStatusBar(self.statusBar)

        # init update
        # init update
        self.image_slicer.reset_items(doc.volume_img.shape[0])
        doc.focus_view = VIEW_NAMES[AXIAL]
        self.update_status_bar(doc.get_current_focus())



        # self.setLayout(self.layout)

        if tab is not None:
            tab.setLayout(self.layout)
        else:
            # frame = Qt.QFrame()
            tab.setLayout(self.layout)
            self.setCentralWidget(tab)

        self.thread = External()
        self.thread.finished.connect(self.update_viewer)
        self.thread.finished.connect(self.closeProgress)

        self.data_set = DataSet(0)
        # self.thread.finished.connect(self.data_list_widget)
        # TODO:test loading doucments
        # TEST_BASE_PATH = "D:/dataset/train/train"
        TEST_BASE_PATH = "D:/dataset/train/test_set/67998_171130153210 (3) (4)/67998_171130153210 (3) (4)_20200318163132.vtk"
        # filename = TEST_BASE_PATH
        # datadoc.load_document(filename)
        # self.update_viewer()
        self.setWindowTitle("DIO-Viewer")
        if tab is None:
            self.show()
        # self.show()

    def coordinate_button_clicked(self):
        # print("click")
        coorbutton = self.sender()
        coorbutton.setText(self.statusBar.currentMessage())
        self.coordinateInfo = coorbutton.text()
        # print("InfoMation", self.coordinateInfo)

        doc = datadoc.get_document()
        # del doc.coordinate_information[:-1]
        if len(doc.coordinate_information) > 0:
            doc.template_coordinate_information.append(doc.coordinate_information[-1])
        # print('coordinate # ', len(doc.coordinate_information))
        print("template length : ", len(doc.template_coordinate_information))
        print("template coordinate", doc.template_coordinate_information)

    def template_save_data(self):
        doc = datadoc.get_document()
        options = Qt.QFileDialog.Options()
        fileName, _ = Qt.QFileDialog.getSaveFileName(self, "QFileDialog.getSaveFileName()", "",
                                                     "Text Files (*.json)", options=options)
        if fileName:
            with open(fileName, 'w') as f:
                json_values = [m.to_json() for m in doc.picking_markers]
                print(json_values)
                json.dump(json_values, f, indent='\t', cls=NpEncoder)

    def save_data(self):
        # print('savedata')
        options = Qt.QFileDialog.Options()
        # options |= Qt.QFileDialog.DontUseNativeDialog
        fileName, _ = Qt.QFileDialog.getSaveFileName(self, "QFileDialog.getSaveFileName()", "",
                                                  "Text Files (*.json)", options=options)
        if fileName:
            # print(fileName)
            with open(fileName, 'w') as f:
                json.dump(self.data_set.__dict__, f, indent='\t')

    def import_data(self):
        # print('import data')
        fileName, _ = Qt.QFileDialog.getOpenFileNames(self, "Import File",
                                                   "", "JSON files (*.json)")
        if fileName:
            # print(fileName)
            with open(fileName[0]) as f:
                slice_class = json.load(f)
                class_num = slice_class.get('img_class')
                size = datadoc.get_document().volume_img.shape[0]
                self.data_set.__dict__.clear()
                self.data_set.__dict__.update(slice_class)
                self.update_slice_widget()
            print("class_num: ", class_num)
            print("size: ", size)

            if len(class_num) != size:
                raise ValueError('not same size volume size & imported data')


    def set_slice_type(self, args):
        # self.ge
        sended_button = self.sender().text()
        selected = [int(it.text()) for it in self.image_slicer.selectedItems()]
        # print(sended_button, selected)
        self.data_set.save(selected, sended_button)

        self.update_slice_widget()

    def update_status_bar(self, pts):
        doc = datadoc.get_document()
        pose = pts * (np.array(doc.volume_img.shape)-1)
        pose = pose.astype(np.int32)
        self.statusBar.showMessage("Focus[{}]: {} ".format(doc.focus_view, pose))

        # vole_index = 0
        view_index = VIEW_NAMES.index(doc.focus_view)
        if view_index == CORONAL:
            volume_index = 1
        elif view_index == SAGITTAL:
            volume_index = 2
        elif view_index == AXIAL:
            volume_index = 0
        slice_size = doc.volume_img.shape[volume_index]
        self.image_slicer.update_items(slice_size)

        # self.image_slicer.

    def update_slice_widget(self, selected:List[int]=None):

        # color_table =
        for i in range(self.image_slicer.count()):
            item = self.image_slicer.item(i)

            cls = self.data_set.img_class[i]
            if cls in COLOR_TABLE:
                color = COLOR_TABLE[cls]
                item.setBackground(color)
            else:
                pass
        # self.data_set.img_class

    def data_load_test(self):
        print("data_load__test")

    def slice_cliecked(self, *args, **kwargs):
        print(args, kwargs)

    def slice_changed(self):
        items = [it for it in self.image_slicer.selectedItems()]
        if len(items) >= 1:
            doc = datadoc.get_document()
            # change focus
            ctr = doc.focus_center
            # only change z-axis
            it = items[-1]
            cur_pose = int(it.text())
            z_length = doc.volume_img.shape[0]

            assert doc.focus_view in VIEW_NAMES
            view_index = VIEW_NAMES.index(doc.focus_view)
            vole_index = 0
            if view_index == CORONAL:
                vole_index = 1
            elif view_index == SAGITTAL:
                vole_index = 2
            elif view_index == AXIAL:
                vole_index = 0
            else:
                raise ValueError('invalid index(view)')

            ctr[vole_index] = cur_pose / (z_length-1)
            doc.change_focus(ctr)

            self.imgwidget1.draw_focus_line()
            self.imgwidget2.draw_focus_line()
            self.imgwidget3.draw_focus_line()
            # doc.volume_img


            # doc.change_focus(ctr)

    def change_db_item(self):

        doc = datadoc.get_document()
        i = self.data_list_widget.currentRow()
        print(self.data_list_widget.currentItem().text())
        doc.change_db_item(i)

        self.update_viewer()


    def clear_current_bbox(self):
        print("clear bbox")
        select_number = int(self.tooth_list_widget.selectedItems()[0].text())
        doc = datadoc.get_document()
        doc.clear_bbox(select_number)



    def convert_pickle_file(self):
        doc = datadoc.get_document()
        doc.docwrite_pickle2itk(overwrite=True)


    def change_bbox(self):
        sender = self.sender()
        if isinstance(sender, ImageWidget) or True:
            boxes = sender.get_boundary_boxes()
            # self.imgwidget1 = ImageWidget(AXIAL)
            # self.imgwidget2 = ImageWidget(SAGITTAL)
            # self.imgwidget3 = ImageWidget(CORONAL)
            update_widget = [self.imgwidget1, self.imgwidget2, self.imgwidget3]
            update_widget.remove(sender)
            if sender.mode == CORONAL:
                inds = [1, 4]
                box2 = self.imgwidget1.get_boundary_boxes()

            elif sender.mode == AXIAL:
                inds = [0, 3]
                box2 = self.imgwidget2.get_boundary_boxes()
                update_widget = [self.imgwidget2, self.imgwidget3]
            elif sender.mode == SAGITTAL:
                inds = [2, 5]
                box2 = self.imgwidget3.get_boundary_boxes()
                update_widget = [self.imgwidget2, self.imgwidget3]
            boxes[inds] = box2[inds]

            select_number = int(self.tooth_list_widget.selectedItems()[0].text())
            doc = datadoc.get_document()
            doc.set_bbox(select_number, boxes)

            for widget in update_widget:
                widget.draw_boundary_box(select_number)

            self.renderer.selection_update([select_number])

    def tooth_stat_update(self, num):
        self.tooth_items_widget.setItems(num)
        self.tooth_items_widget.update_stat()

    def selection_update(self):
        # print(self.tooth_list_widget.selectedItems().text())
        try:
            items = [int(it.text()) for it in self.tooth_list_widget.selectedItems()]
        except Exception as e:
            print(e)
            return
        # num = items[0]
        if items:
            num = items[0]
            doc = datadoc.get_document()
            bbox = doc.get_bbox(num)
            self.tooth_stat_update(num)
            if bbox is not None:
                ctr = (bbox[3:] + bbox[:3])/2
                doc.change_focus(ctr)
                self.imgwidget1.selection_update(num)
                self.imgwidget2.selection_update(num)
                self.imgwidget3.selection_update(num)

            self.renderer.selection_update(items)

    # def apply_all_refinement_mask(self):
    #     pass
    def apply_auto_refinement_mask(self):
        if self.tooth_list_widget.selectedItems():
            # select_number = int(self.tooth_list_widget.selectedItems()[0].text())
            doc = datadoc.get_document()
            for it in self.tooth_list_widget.selectedItems():
                select_number = int(it.text())

                doc.auto_refinement_mask(select_number)
                # self.refresh_current_tooth_image()
            self.selection_update()

    def update_current_items(self):
        doc =  datadoc.get_document()
        doc.write_items(doc.current_db_num)

    def get_stat_filename(self):
        doc = datadoc.get_document()
        return os.path.join(doc.get_save_directory(), "stat.json")

    def save_file(self):
        """
        save status of each teeth
        """

        # self.tooth_items_widget.write_item(self.get_stat_filename())
        self.image_slicer.write_item(self.get_stat_filename())


    def read_dicom(self, filename):
        pathname = os.path.dirname(filename)
        volume, spacing = vtk_utils.read_dicom(pathname)
        volume_8 = (volume * 255).astype(np.uint8)


        voxel = vtk_utils.numpyvolume2vtkvolume(volume_8, 123)
        focal_point = np.array(volume.shape)/2.
        self.renderer.add(voxel, focal_point)

        self.image_slicer.reset_items(volume.shape[0])
        doc = datadoc.get_document()

        doc.set_source(volume_8)

    def open_file(self):
        dlg = Qt.QFileDialog()
        filename, _ = dlg.getOpenFileName(self, "Open dicom files", "", \
                                          "DCM File(*.dcm);;Dicom (*.dcm)")


        # pd = QProgressDialog("Operation in progress.", "Cancel", 0, 100)
        # connect(pd, SIGNAL("canceled()"), self, SLOT("cancel()"))
        if filename:
            datadoc.release_document()
            _, ext = os.path.splitext(filename)

            self.work_dirname = os.path.dirname(filename)
            # doc.set_bbox()

            self.read_dicom(filename)

            size = datadoc.get_document().volume_img.shape[0]

            self.data_set = DataSet(size)
            # connect loading method with thread

            # self.progress.sta
            # self.progress.startAnimation()
            # self.progress.show()
            #
            # doc = datadoc.get_document()
            # # thread = External()
            # DEBUG = False
            # if DEBUG:
            #     doc.load(filename)
            # else:
            #     self.thread.setparam(filename)
            #     # set callback
            #     self.thread.connect(self.read_dicom)
            #     self.thread.start()


            # self.thread.finished()
            # datadoc.load_document(filename)
            # self.update_viewer()
    def closeProgress(self):
        self.progress.stopAnimation()
        self.progress.close()

    @Qt.pyqtSlot()
    def refresh_current_tooth_image(self):
        print("refresh_current_tooth_image")
        # self.renderer.iren.Render()
        self.selection_update()

    def switch_mask(self):
        stat = self.swith_maskAct.data()
        stat = not stat
        self.swith_maskAct.setData(stat)
        self.imgwidget1.drawing_mask = stat
        self.imgwidget2.drawing_mask = stat
        self.imgwidget3.drawing_mask = stat
        self.selection_update()


    def update_viewer(self):
        print(self.sender())
        self.data_list_widget.update_data_list()

        self.renderer.update_image()
        self.imgwidget1.update_image()
        self.imgwidget2.update_image()
        self.imgwidget3.update_image()


        doc = datadoc.get_document()
        zsize = doc.volume_img.shape[0]
        self.image_slicer.reset_items(zsize)
        self.update_stat_items()

        self.setWindowTitle("DIO-Viewer {}".format(self.work_dirname))

    def update_stat_items(self):
        # file = read_tooth_stat()
        # self.tooth_stat_update()
        # self.tooth_items_widget.load_item(self.get_stat_filename())
        # self.image_slicer.load_item(self.get_stat_filename())
        pass


def catch_exceptions(t, val, tb):
    # Qt.QMessageBox.critical(None,
    #                                "An exception was raised",
    #                                "Exception type: {}".format(t))
    raise RuntimeError("An exception was raised",
                                   "Exception type: {}".format(t))
    exit()
    old_hook(t, val, tb)


if __name__=="__main__":
    old_hook = sys.excepthook
    sys.excepthook = catch_exceptions

    app = Qt.QApplication(sys.argv)
    window = MainWindow()
    # window = MarClassifier(None)
    sys.exit(app.exec_())


