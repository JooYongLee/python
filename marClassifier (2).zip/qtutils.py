from PyQt5 import Qt
import numpy as np



def create_action(name, iconpath, short_cut, tips, obj, callback_func):
    action = Qt.QAction(Qt.QIcon(iconpath), name, obj)
    action.setShortcut(short_cut)
    action.setStatusTip(tips)
    action.triggered.connect(callback_func)
    return action

def send_alert_message(str_msg):
    msg = Qt.QMessageBox()

    msg.setStandardButtons(Qt.QMessageBox.Ok)
    msg.setText(str_msg)
    msg.exec()

def is_int( string: str):
    if string[0] in '-' or string[0] in '+':
        return string[1:].isdigit()
    else:
        return string.isdigit()

def numpy2qimage(numpy_array):
    """
    :param numpy_array: numpy array
    :return: QImage
    """
    if numpy_array.ndim == 2:
        ch = 2
        format = Qt.QImage.Format_Grayscale8
    elif numpy_array.ndim == 3:
        if numpy_array.shape[2] == 4:
            format = Qt.QImage.Format_RGBA8888
        elif numpy_array.shape[2] == 3:
            format = Qt.QImage.Format_RGB888
        else:
            raise ValueError

    h = numpy_array.shape[0]
    w = numpy_array.shape[1]

    img = numpy_array
    return Qt.QImage(img.tobytes(), w, h, img.strides[0], format)


def qimage2numpy(qimage: Qt.QImage):
    if qimage.format() == Qt.QImage.Format_Grayscale8:
        bits = qimage.bits()

        bits.setsize(qimage.width() * qimage.height() * 1)
        arr = np.frombuffer(bits, np.uint8).reshape([qimage.height(), qimage.width()])

    elif qimage.format() == Qt.QImage.Format_RGB888:
        bits = qimage.bits()
        bits.setsize(qimage.width() * qimage.height() * 3)
        arr = np.frombuffer(bits, np.uint8).reshape([qimage.height(), qimage.width(), 3])
    elif qimage.format() == Qt.QImage.Format_RGB32:
        bits = qimage.bits()
        bits.setsize(qimage.width() * qimage.height() * 4)
        temp = np.frombuffer(bits, np.uint8).reshape([qimage.height(), qimage.width(), 4])
        arr = temp[:, :, :3].copy()

    else:
        raise NotImplementedError

    return arr

#global
# volume_counters = 0
def region_grow(vol, src_mask, start_point, spacing, epsilon=150, fill_with=1, thresh=255):
    sizez = vol.shape[0] - 1
    sizex = vol.shape[1] - 1
    sizey = vol.shape[2] - 1

    items = []
    visited = []

    mask = src_mask.copy()

    global volume_counters
    volume_counters = 0

    def enqueue(item):
        global volume_counters
        items.insert(0, item)
        mask[item[0], item[1], item[2]] = fill_with
        volume_counters = volume_counters  + 1


    def dequeue():
        s = items.pop()
        visited.append(s)
        return s

    enqueue((start_point[0], start_point[1], start_point[2]))

    issuccess = True

    mm2_per_pixel3 = np.prod(spacing)
    TOOTH_VOLUME_THRESH = TOOTH_VOLUME_THRESH_MM3 / mm2_per_pixel3

    while not items == []:

        z, x, y = dequeue()

        # if enqueue_cnts % 100 ==0 :
        #     print("counting volume : ".format(enqueue_cnts))
        if volume_counters > TOOTH_VOLUME_THRESH:
            print("counting volume breaked : #{} , mm3/pixel3 {}".format(volume_counters, mm2_per_pixel3))
            issuccess = False
            break

        # voxel = vol[z, x, y]


        if x < sizex:
            tvoxel = int(vol[z, x + 1, y])
            inside = int(mask[z, x + 1, y])

            if tvoxel == thresh and inside != fill_with:
                # print(tvoxel, thresh, fill_with)
                enqueue((z, x + 1, y))


        if x > 0:
            tvoxel = int(vol[z, x - 1, y])
            inside = int(mask[z, x - 1, y])
            if tvoxel == thresh and inside != fill_with:
                enqueue((z, x - 1, y))

        if y < sizey:
            tvoxel = int(vol[z, x, y + 1])
            inside = int(mask[z, x, y + 1])
            if tvoxel == thresh and inside != fill_with:
                enqueue((z, x, y + 1))

        if y > 0:
            tvoxel = int(vol[z, x, y - 1])
            inside = int(mask[z, x, y - 1])
            if tvoxel == thresh and inside != fill_with:
                enqueue((z, x, y - 1))

        if z < sizez:
            tvoxel = int(vol[z + 1, x, y])
            inside = int(mask[z + 1, x, y])
            if tvoxel == thresh and inside != fill_with:
                enqueue((z + 1, x, y))

        if z > 0:
            tvoxel = int(vol[z - 1, x, y])
            inside = int(mask[z - 1, x, y])
            if tvoxel == thresh and inside != fill_with:
                enqueue((z - 1, x, y))

    if issuccess:
        src_mask[:, :, ] = mask[:, :, :]

    return issuccess, volume_counters

def region_grow_(vol, mask, start_point, epsilon=150, fill_with=1, thresh=255):
    sizez = vol.shape[0] - 1
    sizex = vol.shape[1] - 1
    sizey = vol.shape[2] - 1

    items = []
    visited = []

    def enqueue(item):
        items.insert(0, item)
        mask[item[0], item[1], item[2]] = fill_with


    def dequeue():
        s = items.pop()
        visited.append(s)
        return s

    enqueue((start_point[0], start_point[1], start_point[2]))

    while not items == []:

        z, x, y = dequeue()

        voxel = vol[z, x, y]
        # mask[z, x, y] = fill_with
        # print("region",len(items))

        if x < sizex:
            tvoxel = int(vol[z, x + 1, y])
            inside = int(mask[z, x + 1, y])

            if (abs(tvoxel - voxel) < epsilon and inside == thresh ) or \
                    ( inside != fill_with and tvoxel != 0):
                # print(tvoxel, thresh, fill_with)
                enqueue((z, x + 1, y))


        if x > 0:
            tvoxel = int(vol[z, x - 1, y])
            inside = int(mask[z, x - 1, y])
            if (abs(tvoxel - voxel) < epsilon and inside == thresh)or \
                    ( inside != fill_with and tvoxel != 0):
                enqueue((z, x - 1, y))

        if y < sizey:
            tvoxel = int(vol[z, x, y + 1])
            inside = int(mask[z, x, y + 1])
            if (abs(tvoxel - voxel) < epsilon and inside == thresh)or \
                    ( inside != fill_with and tvoxel != 0):
                enqueue((z, x, y + 1))

        if y > 0:
            tvoxel = int(vol[z, x, y - 1])
            inside = int(mask[z, x, y - 1])
            if (abs(tvoxel - voxel) < epsilon and inside == thresh)or \
                    ( inside != fill_with and tvoxel != 0):
                enqueue((z, x, y - 1))

        if z < sizez:
            tvoxel = int(vol[z + 1, x, y])
            inside = int(mask[z + 1, x, y])
            if (abs(tvoxel - voxel) < epsilon and inside == thresh) or\
                    ( inside != fill_with and tvoxel != 0):
                enqueue((z + 1, x, y))

        if z > 0:
            tvoxel = int(vol[z - 1, x, y])
            inside = int(mask[z - 1, x, y])
            if (abs(tvoxel - voxel) < epsilon and inside > thresh) or \
                    ( inside != fill_with and tvoxel != 0):
                enqueue((z - 1, x, y))