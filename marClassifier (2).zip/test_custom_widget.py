from Custom_Widgets.ProgressIndicator import test
# from Custom_Widgets.main import

# test.main()

from Custom_Widgets import ProjectMaker