from PyQt5 import Qt
import numpy as np


class GuideROI(Qt.QGraphicsLineItem):
    def __init__(self, parent=None, mode=Qt.Qt.Horizontal):
        """
        라인 graphics 아이템
        색상 관리, 선 특성 관리
        이동 처리
        :param parent:
        :param mode: Horizontal or Vertical, Horizontal ---> x, Vertical ---> y
        """
        super(GuideROI, self).__init__(parent)

        pen = Qt.QPen()
        pen.setColor(Qt.Qt.red)
        pen.setWidth(2)

        self.default_pen = pen
        pen = Qt.QPen()
        pen.setColor(Qt.Qt.yellow)
        pen.setWidth(3)
        self.select_pen = pen

        self.update_pen()

        self.setFlag(Qt.QGraphicsLineItem.ItemIsSelectable, True)

        self.mode = mode

        self._min = -1000
        self._max = 1000

        default_pen = Qt.QPen()
        default_pen.setColor(Qt.Qt.blue)
        default_pen.setWidth(2)
        default_pen.setDashPattern([1, 4])
        select__pen = Qt.QPen()
        select__pen.setColor(Qt.Qt.cyan)
        select__pen.setWidth(2)

        self.pen_pack = [
            [default_pen, select__pen]
        ]

    def getpose(self):
        p1 = [self.line().y1(), self.line().x1()]
        p2 = [self.line().y2(), self.line().y2()]
        return p1, p2

    # def change_default_color(self, color):
    #     """"""
    #
    #      # color: r, g, b float type 0 ~ 1 value
    #     color = (np.asarray(color) * 255)).astype(np.int)
    #
    def change_default_pen(self, color):
        """
        :param color: r, g, b float type 0 ~ 1 value
        :return:
        """
        # color = (np.asarray(color) * 255)).astype(np.int)
        color = (np.asarray(color)* 255).astype(np.int)
        default_pen = Qt.QPen()
        default_pen.setColor(Qt.QColor(*color))
        default_pen.setWidth(2)

        # self.setPen(default_pen)
        # self.pen_pack[0] = default_pen
        # self.select_pen = default_pen
        self.default_pen = default_pen
        self.update_pen()


    def change_pen(self, mode:int=0):
        select_pen = self.pen_pack[0][1]
        default_pen = self.pen_pack[0][0]
        self.select_pen = select_pen
        self.default_pen = default_pen
        self.update_pen()

    def update_pen(self):
        if not self.isSelected():
            self.setPen(self.default_pen)
        else:
            self.setPen(self.select_pen)

    def setMinMax(self, imin, imax):
        self._min = imin
        self._max = imax
        self._diff = self._max - self._min


    def move_the_line(self, value):
        """
        :param value:
        :return:
        """
        value = np.clip(value, self._min, self._max)
        if self.mode == Qt.Qt.Horizontal:
            self.setLine(self.line().x1(),
                         value,
                         self.line().x2(),
                         value)
        else:
            self.setLine(value,
                         self.line().y1(),
                         value,
                         self.line().y2()
                         )

    def set_pos(self, value):
        trans_value = value * self._diff + self._min
        self.move_the_line(trans_value)

    def get_pos(self):
        """
        :return: current position in where 0 ~ 1
        """
        if self.mode == Qt.Qt.Horizontal:
            value = self.line().y1()
        else:
            value = self.line().x1()

        return ( value - self._min )  / self._diff

    def change_selected_mode(self, flag:bool):
        self.setSelected(flag)
        self.update_pen()

# class ImgFocusROI(GuideROI):
#     def __init__(self, parent=None, mode=Qt.Qt.Horizonta):
#
#         super(ImgFocusROI, self).__init__(parent)