import numpy as np
import glob
from PyQt5 import Qt
import os

import vtk
# from toothNet.teethConfigure import get_teeth_color_table
# from toothNet.ImgdbBase import ImgDb, VolumeData, teeth_label_table
# from toothNet import vtk_utils
# from toothNet import image_utils
from QProgressIndicator import External, QProgressIndicator

import pickle
from PyQt5 import Qt
import time
import qtutils





def convert_vtkvolume(crop, bbox, tau):
    color_table = get_teeth_color_table()

    # for crop, bbox, tau in zip(crop_volume, crop_bbox, crop_taus):
    z1, y1, x1 = bbox[:3]
    # crop = gaussian_filter(crop.astype(np.float), 0.8)
    actor = vtk_utils.convert_numpy_2_vtkmarching(crop*255, 123)
    t = vtk.vtkTransform()
    t.Translate(x1, y1, z1)
    actor.SetUserTransform(t)
    c = color_table[tau%10]
    actor.GetProperty().SetColor(*c)
    actor.GetMapper().ScalarVisibilityOff()
    return actor


def region_grow(volume, mask, start_point, fill_with=1):
    sizez = volume.shape[0] - 1
    sizey = volume.shape[1] - 1
    sizex = volume.shape[2] - 1

    items = []
    visited = []

    def enqueue(item):
        items.insert(0, item)
        mask[item[0], item[1], item[2]] = fill_with

    def dequeue():
        s = items.pop()
        visited.append(s)
        return s

    enqueue((start_point[0], start_point[1], start_point[2]))

    check_func1 = lambda x, y: x != y
    check_func2 = lambda x, y: x == y

    # check_func1 = lambda x, y: x == y
    while not items == []:
        z, y, x = dequeue()

        # print(z, y, x)
        # mask[z, x, y] = fill_with
        # print("region",len(items))

        if x < sizex:

            xt = x + 1
            tvalue = int(mask[z, y, xt])
            curvalue = volume[z, y, xt]
            if check_func1(tvalue, curvalue) and check_func2(tvalue, 0):
                enqueue((z, y, xt))

        if x > 0:
            xt = x - 1
            tvalue = int(mask[z, y, xt])
            curvalue = volume[z, y, xt]
            if check_func1(tvalue, curvalue) and check_func2(tvalue, 0):
                enqueue((z, y, xt))

        if y < sizey:
            yt = y + 1
            tvalue = int(mask[z, yt, x])
            curvalue = volume[z, yt, x]
            if check_func1(tvalue, curvalue) and check_func2(tvalue, 0):
                enqueue((z, yt, x))

        if y > 0:
            yt = y - 1
            tvalue = int(mask[z, yt, x])
            curvalue = volume[z, yt, x]
            if check_func1(tvalue, curvalue) and check_func2(tvalue, 0):
                enqueue((z, yt, x))

        if z < sizez:
            zt = z + 1
            tvalue = int(mask[zt, y, x])
            curvalue = volume[zt, y, x]
            if check_func1(tvalue, curvalue) and check_func2(tvalue, 0):
                enqueue((zt, y, x))

        if z > 0:
            zt = z - 1
            tvalue = int(mask[zt, y, x])
            curvalue = volume[zt, y, x]
            if check_func1(tvalue, curvalue) and check_func2(tvalue, 0):
                enqueue((zt, y, x))

    return mask




def denorm_boxes(boxes, shape):
    boxes = np.asarray(boxes)
    shape = np.asarray(shape)
    # shift 1
    shape = np.concatenate([shape, shape]) - 1.
    return boxes * shape

def norm_boxes(boxes, shape):
    boxes = np.asarray(boxes)
    shape = np.asarray(shape)
    # shift 1
    shape = np.concatenate([shape, shape]) - 1.
    return boxes / shape


class DataDoc(Qt.QObject):
    loadComleteSignal = Qt.pyqtSignal()
    auto_refinement = Qt.pyqtSignal()
    focus_change_signal = Qt.pyqtSignal(np.ndarray)
    def __init__(self):
        super(DataDoc, self).__init__()
        # self.focus_change_signal = Qt.pyqtSignal(np.ndarray)

        self.current_db_num = 0
        self.path = ""
        # to visualize image
        # self.vtkpolydata = vtk.vtkPolyData()
        # self.vtkimagedata = vtk.vtkImageData()
        self.volume_vtk = vtk.vtkVolume()

        # current document image
        # TODO:Test volume img?
        self.volume_img = np.zeros([300, 400, 500], dtype=np.uint8)
        self.volume_mask = np.zeros([300, 500, 500], dtype=np.uint8)
        self.color_volume_mask = np.zeros([*self.volume_mask.shape, 3], dtype=np.uint8)
        self.focus_center = np.ones([3]) / 2
        self.viewprops = {}
        self.crop_bbox = {}
        self.crop_voxel = {}
        self.crop_taus = []
        self.edited_taus = {}

        # 좌표 저장
        self.coordinate_information = []
        self.template_coordinate_information = []

        # marker 저장
        self.picking_markers = []
        # self.imgdb = ImgDb("", False, True)
        # self.progress = QProgressIndicator(None)
        self.focus_view = ''

    def reset(self):
        self.current_db_num = 0
        self.path = ""
        # to visualize image
        # self.vtkpolydata = vtk.vtkPolyData()
        # self.vtkimagedata = vtk.vtkImageData()
        self.volume_vtk = vtk.vtkVolume()


        # current document image
        # TODO:Test volume img?
        self.volume_img = np.zeros([400, 500, 500], dtype=np.uint8)
        self.volume_mask = np.zeros([400, 500, 500], dtype=np.uint8)
        self.color_volume_mask = np.zeros([*self.volume_mask.shape, 3], dtype=np.uint8)
        self.focus_center = np.ones([3]) / 2
        self.viewprops = {}
        self.crop_bbox = {}
        self.crop_voxel = {}
        self.crop_taus = []
        self.edited_taus = {}
        # self.imgdb = ImgDb("", False, True)

    def set_source(self, volume_img):
        self.volume_img = volume_img
        self.volume_mask = np.zeros_like(volume_img)
        self.color_volume_mask =  np.zeros([*self.volume_mask.shape, 3], dtype=np.uint8)

    def set_bbox(self, number, bbox):
        if number in self.crop_bbox:
            # status change if box is changed
            self.edited_taus[number] = True
            self.crop_bbox[number] = bbox

    def get_bbox(self, number):
        return self.crop_bbox.get(number, None)

    def is_edited(self, number):
        return self.edited_taus[number]

    def write_cache(self):
        if self.imgdb.volume_img:
            voldb = self.imgdb.volume_img[0]
            assert isinstance(voldb, VolumeData) or True
            crop_vox = {}
            taus = {}
            for number in self.crop_taus:
                box = denorm_boxes(self.crop_bbox[number], self.volume_mask.shape)
                box = np.round(box).astype(np.int)
                z1, y1, x1, z2, y2, x2 = box
                crop = self.volume_mask[z1:z2, y1:y2, x1:x2].copy()
                crop_vox[number] = crop==number
                taus[number] = number

            voldb.update(
                self.volume_img,
                self.volume_mask,
                crop_vox,
                self.crop_bbox,
                taus
            )
            # self.imgdb.load_volume_set()
            self.imgdb.write_cache_file(voldb)

    def refinement_edited_taus(self):
        for tau in self.crop_taus:
            if self.is_edited(tau):
                self.apply_box_mask(tau)
                # print(tau, "applymask")
            else:
                pass

    def write_file(self, num=None):
        for tau in self.crop_taus:
            if self.is_edited(tau):
                self.apply_box_mask(tau)
                # print(tau, "applymask")
            else:
                pass
                # print(tau, "passed")
        # tooth number ----> sequencth teeth label
        # from index to tooth number



        DEBUG = False

        if DEBUG:
            import vtk_utils
            bbox = denorm_boxes(np.array(list(self.crop_bbox.values())), self.volume_mask.shape)
            bbox_vtk = vtk_utils.convert_box_norm2vtk(bbox)
            cube_vtk = [vtk_utils.get_cube(b) for b in bbox_vtk]
            vtk_utils.show_actors([*cube_vtk, vtk_utils.numpyvolume2vtkvolume(self.volume_mask*255, 123)])

            # vtk_utils.visulaize(self.crop_voxel[16]*255, 123)
            # self.crop_taus
            denorm_bbox = denorm_boxes(np.array(list(self.crop_bbox.values())), self.volume_mask.shape)
            crop_actors = vtk_utils.convert_volume_labeling(list(self.crop_voxel.values()),
                                                            denorm_bbox,
                                                            self.crop_taus)

            vtk_utils.show_actors([*crop_actors, *cube_vtk])

            i = list(self.crop_bbox.keys()).index(16)
            ibox = denorm_bbox[i].astype(np.int)
            z1, y1, x1, z2, y2, x2 = ibox
            print(ibox[3:] - ibox[:3])
            v1 = vtk_utils.numpyvolume2vtkvolume(self.crop_voxel[16]*255, 123)
            v2 = vtk_utils.numpyvolume2vtkvolume(self.volume_mask[z1:z2, y1:y2, x1:x2]*255, 123)
            vtk_utils.show_actors([v1, v2])

        # self.imgdb.write_pickle()
        extension = os.path.splitext(self.path)[-1]
        if extension == ".pkl":
            num = self.current_db_num
            self.write_items(num)
            self.imgdb._write_volume_dataset(self.path)
            print("overwriting complete", self.path)
        elif extension == ".vtk":
            labels_fdi2itk = np.zeros([50], dtype=np.uint8)
            for lab, tau in teeth_label_table.items():
                labels_fdi2itk[tau] = lab
            labels_fdi2itk[0] = 0

            mask_itk = labels_fdi2itk[self.volume_mask]
            ImgDb.write_dataset_from_vtk2itk(self.path, mask_itk)
            # vtk.vtkMetaImageWriter
            # vtk.vtkXMLImageDataWriter\
            # write_dataset_from_vtk2itk(self.path, mask_itk)

    def get_save_directory(self):

        # #for voldb in self.imgdb.volume_img:
        # if self.imgdb.volume_img:
        #     voldb = self.imgdb.volume_img[0]
        #     assert isinstance(voldb, VolumeData) or True
        #     save_dir = os.path.dirname(voldb._source_directory)
        #     return save_dir
        # else:
        #     return ""
        pass

    def get_workid(self):
        if self.imgdb.volume_img:
            voldb = self.imgdb.volume_img[0]
            assert isinstance(voldb, VolumeData) or True
            name = os.path.basename(os.path.dirname(voldb._source_directory))
            return name
        else:
            return ""

    def docwrite_pickle2itk(self, overwrite=True):

        labels_fdi2itk = np.zeros([50], dtype=np.uint8)
        for lab, tau in teeth_label_table.items():
            labels_fdi2itk[tau] = lab
        labels_fdi2itk[0] = 0

        self.refinement_edited_taus()

        for voldb in self.imgdb.volume_img:
            assert isinstance(voldb, VolumeData) or True
            save_dir = os.path.dirname(voldb._source_directory)
            workname = os.path.basename(save_dir)
            savename = os.path.join(save_dir, "{}_{}.pkl".format(workname, time.strftime("%Y%m%d%H%M%S")))
            if overwrite:
                vtk_existing_list = glob.glob(save_dir + "/*.vtk")
                if vtk_existing_list:
                    savename = vtk_existing_list[0]

            print("writing....\t", savename)

            mask_itk = labels_fdi2itk[voldb.full_segment_mask]
            #ImgDb.write_dataset_from_vtk2itk(savename, mask_itk, voldb.spacing.tolist())

            msg = "writing...{}\n complete".format(savename)

            qtutils.send_alert_message(msg)


    def clear_bbox(self, number):

        zeros = np.zeros_like(self.volume_mask)
        self.crop_bbox.pop(number)
        self.crop_voxel.pop(number)
        self.crop_taus.remove(number)
        self.volume_mask[:] = np.where(
            self.volume_mask == number,
            zeros,
            self.volume_mask
        )

    def auto_refinement_mask(self, number):
        # remove noise out of box
        self.apply_box_mask(number)
        if number in self.crop_bbox:
            # get sample idx
            fbox = np.clip(self.crop_bbox[number], 0, 1)
            box = denorm_boxes(fbox, self.volume_mask.shape)
            ibox = np.round(box).astype(np.int)
            z1, y1, x1, z2, y2, x2 = ibox
            crop = self.volume_mask[z1:z2, y1:y2, x1:x2].copy()
            # center of index
            bool_mask = crop == number
            ix = np.stack(np.where(bool_mask), axis=-1)
            center = np.round(np.mean(ix, axis=0)).astype(np.int)

            # region growing in center of mass, remove other index
            umask = bool_mask.astype(np.uint8)
            region_mask = np.zeros_like(umask)
            region_grow(umask, region_mask, center)
            DEBUG = False
            if DEBUG:
                vtk_utils.visulaize(self.volume_mask*255, 123)
                vtk_utils.visulaize(crop*255, 123)
                import matplotlib.pyplot as plt
                for img1, img2 in zip(umask, region_mask):
                    img = img1 + img2
                    plt.cla()
                    plt.imshow(img)
                    plt.pause(0.01)

            # data update to export
            old_mask = bool_mask
            new_mask = region_mask > 0
            inds = np.stack(np.where(new_mask), axis=-1)
            p1 = inds.min(axis=0)
            p2 = inds.max(axis=0)
            t1 = ibox[:3]
            offset = [3, 3, 3]
            max_inds = np.array(umask.shape)
            cp1 = np.clip(p1 - offset, 0, max_inds)
            cp2 = np.clip(p2 + offset, 0, max_inds)
            new_p1 = t1 + cp1
            new_p2 = t1 + cp2

            new_bbox = norm_boxes(np.concatenate([new_p1, new_p2]), self.volume_mask.shape)
            self.set_bbox(number, new_bbox)

            cz1, cy1, cx1 = cp1
            cz2, cy2, cx2 = cp2

            self.crop_voxel[number] = region_mask[cz1:cz2, cy1:cy2, cx1:cx2]
            # set crop box
            self.volume_mask[z1:z2, y1:y2, x1:x2] = np.where(old_mask,
                                                             new_mask * number,
                                                             crop)

            # rendering update
            self.viewprops[number] = convert_vtkvolume(new_mask, box, number)

            # self.auto_refinement.emit()
            # update mask

    def apply_box_mask(self, number):
        if number in self.crop_bbox:
            print("apply mask", number)
            box = denorm_boxes(self.crop_bbox[number], self.volume_mask.shape)
            box = np.round(box).astype(np.int)
            z1, y1, x1, z2, y2, x2 = box
            crop = self.volume_mask[z1:z2, y1:y2, x1:x2].copy()
            crop_voxel = crop == number
            # self.volume_mask[z1:z2, y1:y2, x1:x2] = np.where(crop_number, crop_number * number, crop)
            self.crop_voxel[number] = crop_voxel


            zeros = np.zeros_like(self.volume_mask)
            # set to zero in areaa out of boux
            self.volume_mask[:] = np.where(self.volume_mask == number, zeros, self.volume_mask)
            # set crop box
            self.volume_mask[z1:z2, y1:y2, x1:x2] = np.where(crop_voxel, crop_voxel * number, crop)

            self.edited_taus[number] = False
            # vtk_utils.visulaize((crop==number)*255, 123)

    def load(self, itk_filename):
        # thread = External()
        # TODO:read from vtk.. to test from imagdb
        #
        # qthread = QProgressIndicator.QProgressIndicator()
        self.path = itk_filename
        # filename = "items.pkl"
        # if os.path.exists(filename) and False:
        if os.path.splitext(itk_filename)[-1] == ".pkl":
            del self.imgdb
            self.imgdb = ImgDb("", manual_load=True)
            self.imgdb.read_pickle(itk_filename)
            print("loading pickle file")
            self.change_db_item(0)



        else:
            itk_filepath = os.path.dirname(itk_filename)
            # set save name
            imgdb = ImgDb(itk_filepath, False, manual_load=True)
            imgdb.load_volume_set_from_workpath(itk_filepath)
            self.imgdb = imgdb
            self.change_db_item(0)

        # writer = vtk.vtkImageWriter()
        # writer = vtk.vtkMetaImageWriter()
        self.loadComleteSignal.emit()
        # self.loadComleteSignal.emit()

    def change_db_item(self, num):
        self.current_db_num = num
        imgdb = self.imgdb
        if imgdb.volume_img:


            voldb = imgdb.volume_img[num]
            volume_img = imgdb.volume_img[num].volume
            volume_mask = imgdb.volume_img[num].full_segment_mask
            crop_list = voldb.get_items(use_minimask=True)

            # color_table = self.get_color_table()
            # actors, crop_list = vtk_utils.extract_volume_labeling(volume_mask, color_table, return_crop=True)

            write_items = [volume_img, volume_mask, *crop_list]
            # with open(filename, "wb") as f:
            #     pickle.dump(write_items, f)
            self.clear_items()
            self.load_items_prepare(write_items)

    def get_color_table(self):
        color_table = np.zeros([50, 3])
        tables = get_teeth_color_table()
        for i in range(1, 5):
            for j in range(1, 9):
                tau = i * 10 + j
                color_table[tau] = tables[tau % 10]
        return color_table

    def clear_items(self):
        self.crop_bbox.clear()
        self.crop_voxel.clear()
        self.crop_taus.clear()
        self.edited_taus.clear()
        self.viewprops.clear()

    def write_items(self, num):
        if num is not None:
            imgdb = self.imgdb
            if imgdb.volume_img:
                voldb = imgdb.volume_img[num]
                voldb.overwrite(
                    self.crop_voxel,
                    self.crop_bbox,
                    self.crop_taus,
                    self.volume_mask
                )


    def load_items_prepare(self, load_items):
        self.volume_img, self.volume_mask, crop_volume, crop_bbox, crop_taus = \
            load_items
        color_table = self.get_color_table()

        color_table_uint8 = (color_table * 255).astype(np.uint8)

        maxinds = (np.array(self.volume_img.shape) - 1)
        crop_bbox_norm = np.asarray(crop_bbox) / np.pad(maxinds, [0, 3], mode='wrap')
        for tau, bbox, vol in zip(crop_taus, crop_bbox_norm, crop_volume):
            self.crop_bbox[tau] = bbox
            self.crop_taus.append(tau)
            self.edited_taus[tau] = False
            self.crop_voxel[tau] = vol

        self.color_volume_mask = color_table_uint8[self.volume_mask]
        volume = vtk_utils.numpyvolume2vtkvolume(self.volume_img, 123)
        self.volume_vtk = volume

        # stting center
        self.focus_center = np.ones([3]) / 2
        crop_actors = vtk_utils.convert_volume_labeling(crop_volume, crop_bbox, crop_taus)

        actors_dict = dict([(key, value) for key, value in zip(crop_taus, crop_actors) ])

        actors_dict.update({"volume":volume})
        # actors += crop_actors
        # actors.append(volume)
        # for vol, lab in zip(crop_volume, crop_taus)
        self.viewprops = actors_dict

    def get_current_focus(self, normalize=True):
        ctr = self.focus_center
        return ctr

    def change_focus(self, ctr):
        ctr = np.asarray(ctr)
        self.focus_center = ctr
        # print(id(self.focus_change_signal), id(self.loadComleteSignal), id(self.auto_refinement))
        self.focus_change_signal.emit(ctr)
        # self.focus_change_signal.emit()
        # print("cener changed", ctr)

    def world2display(self, pose, shape):
        """
        :param pose:[3]  array
        :param shape: (height, width) 2 tuple
        :return:
        """
        image_utils.norm_boxes(pose, )

    def get_color(self, num):
        from teethConfigure import get_teeth_color_table
        color_table = get_teeth_color_table()
        num = num % 10
        color_table[num]



document = DataDoc()

def release_document():
    # global document
    # del document
    # create new instance
    document.reset()

def get_document():
    # global document
    # if document is None:
    #     document =
    return document

def load_document(path):
    document.load(path)

