from PyQt5 import Qt
import os
import numpy as np
import json
class ImageSlicer(Qt.QListWidget):
    Normal = 0
    Metal = 1
    color_bank ={
        Normal:Qt.Qt.white,
        Metal:Qt.Qt.green
    }

    slice_changed_signal = Qt.pyqtSignal()
    def __init__(self):
        super(ImageSlicer, self).__init__()
        self.setSelectionMode(Qt.QAbstractItemView.ExtendedSelection)
        self.setMaximumWidth(200)

    def help(self):
        return "normal : {} metal : {}".format(self.Normal, self.Metal)

    def write_item(self, filename):
        # default all nomral
        stat_data = np.ones([self.count()], dtype=np.int) * self.Normal
        for i in range(self.count()):
            it = self.item(i)
            stat = it.data(Qt.Qt.UserRole)
            stat_data[i] = stat
        todata = {
            "status":stat_data.tolist(),
            "help":self.help()
        }
        with open(filename, "w") as f:
            json.dump(todata, f, indent='\t')


    def load_item(self, filename):
        if not os.path.exists(filename):
            return
        with open(filename, "r") as f:
            data = json.load(f)
        if not "status" in data:

            return

        stat = data["status"]
        if len(stat) == self.count():
            # loading status
            for i in range(self.count()):
                s = int(stat[i])
                it = self.item(i)
                it.setData(Qt.Qt.UserRole, Qt.QVariant(s))

            # change color
            self.update_stat()
        else:
            raise ValueError("loaded invalid items")

    def update_stat(self):
        for i in range(self.count()):
            it = self.item(i)
            data = it.data(Qt.Qt.UserRole)
            color = self.color_bank[data]
            it.setBackground(color)


    def remove_items(self):
        for i in reversed(range(self.count())):
            # it = self.item(i)
            self.takeItem(i)

    def update_items(self, size):
        """
        현재 아이템 개수를 비교해서 다를 경우 개수를 갱신한다.
        """
        if size == self.count():
            pass
        else:
            self.reset_items(size)

    def setColorAtItem(self, itemNumber, color:Qt.QColor):
        item = self.item(itemNumber)
        item.setBackground(color)



    def reset_items(self, size):
        self.remove_items()
        for i in range(size):
            item_str = "{:03d}".format(i)
            item = Qt.QListWidgetItem()
            item.setText(item_str)
            item.setData(Qt.Qt.UserRole, Qt.QVariant(self.Normal))
            color = self.color_bank[self.Normal]
            item.setBackground(color)
            self.addItem(item)

    def keyPressEvent(self, event):
        key = event.key()
        if key in [Qt.Qt.Key_Space, Qt.Qt.Key_Enter]:
            self.change_stat_selected_items()
            self.update_color_selected_items()

        return Qt.QListWidget.keyPressEvent(self, event)

    def update_color_selected_items(self):
        for it in self.selectedItems():
            data = it.data(Qt.Qt.UserRole)
            color = self.color_bank[data]
            it.setBackground(color)


    def change_stat_selected_items(self):
        for it in self.selectedItems():
            data = it.data(Qt.Qt.UserRole)
            data = self.Normal if data == self.Metal else self.Metal
            it.setData(Qt.Qt.UserRole, Qt.QVariant(data))
            # print(it.text(), data)




