import numpy as np
import cv2
import os
from PyQt5 import Qt
from collections import OrderedDict
# from PyQt5 import QtCore

import qtutils
from qtutils import create_action
from common import get_runtime_logger

datatype_table = OrderedDict({
    '8-bit': 'uint8',
    '16-bit Signed': 'int16',
    '16-bit Unsigned': 'uint16'
})

class RawImageParam(object):
    def __init__(self):
        pass
        self.white_zero = True
        self.width = 0
        self.height = 0
        self.little_endian = True
        self.dtype = 'int16'

    def __repr__(self):
        smg = 'white zero : {} [WXH:{}x{}] / little-endian:{}, {}'.format(
            self.white_zero, self.width, self.height, self.little_endian, self.dtype)
        return smg


class DicomImageView(Qt.QGraphicsView):
    def __init__(self):
        super(DicomImageView, self).__init__()

        self.width = 1920
        self.height = 1080
        self.scene = Qt.QGraphicsScene()
        self.setScene(self.scene)

        # self.setScene()
        self.setAcceptDrops(True)
        self.setDragMode(True)

        # source pixmap
        self.pixmap = None # type:Qt.QGraphicsPixmapItem
        # processed pixmap
        self.procssed_pixmap = None # type:Qt.QGraphicsPixmapItem
        self.init_image()

    def init_image(self):
        img = np.zeros([self.height, self.width, 3], dtype='uint8')
        self.pixmap = Qt.QGraphicsPixmapItem()
        self.pixmap.setPixmap(Qt.QPixmap(qtutils.numpy2qimage(img)))
        # self.addItem(self.pixmap)
        self.scene.addItem(self.pixmap)

    def remove_image(self):
        """
        # source image 제거
        """
        if self.pixmap is not None:
            # self.removeItem(self.pixmap)
            self.scene.removeItem(self.pixmap)
            self.pixmap = None
        else:
            pass
            # logger = get_runtime_logger()
            # logger.error('not selected pixmap')

        if self.procssed_pixmap is not None:
            self.scene.removeItem(self.procssed_pixmap)
            self.procssed_pixmap = None


    def get_image(self)->np.ndarray:
        # from pixmap to qimage
        qimg = self.pixmap.pixmap().toImage()
        numpy_img = qtutils.qimage2numpy(qimg)
        return numpy_img

    def update_process_image(self, numpy_array):
        self.remove_image()
        logger  = get_runtime_logger()
        numpy_img = numpy_array
        if numpy_array.dtype != 'uint8':
            logger.warn('may be result in incorrect visualized')
            numpy_img = numpy_array.astype('uint8')
        numpy_img = self._resize_image(numpy_img)
        self.procssed_pixmap = Qt.QGraphicsPixmapItem()
        self.procssed_pixmap.setPixmap(Qt.QPixmap(qtutils.numpy2qimage(numpy_img)))
        self.scene.addItem(self.procssed_pixmap)

    def _resize_image(self, img_array):
        img = cv2.resize(img_array, (self.width, self.height))
        img = img.astype('uint8')
        return img

    def add_image(self, filename:str, param:RawImageParam):

        if not os.path.exists(filename):
            logger = get_runtime_logger()
            logger.error('emtpy file:{}'.format(filename))
            return

        self.remove_image()

        # filename = 'Panoramic_2d(2637x1216).raw'
        with open(filename, 'rb') as f:
            buf = f.read()
            # img = np.fromfile(f, dtype='<u2', sep="")  # >: big endian, <: little endian, u2: uint16
            dtype = np.dtype(param.dtype)
            if param.little_endian:
                dtype = dtype.newbyteorder('<')
            else:
                dtype = dtype.newbyteorder('>')

            img = np.frombuffer(buf, dtype=dtype)# >: big endian, <: little endian, u2: uint16

            # size check
            if np.prod(img.shape) == (param.width*param.height):
                img = img.reshape([param.height, param.width])
                img = (img - img.min()) / (img.max() - img.min()) * 255
                if param.white_zero:
                    img = 255 - img

                img = self._resize_image(img)
                    # np.frombuffer(buf, [2])
                self.pixmap = Qt.QGraphicsPixmapItem()
                self.pixmap.setPixmap(Qt.QPixmap(qtutils.numpy2qimage(img)))
                # self.addItem(self.pixmap)
                self.scene.addItem(self.pixmap)
            else:
                logger = get_runtime_logger()
                logger.warn('invalid image size:{}x{}'.format(param.width, param.height))


class QDropList(Qt.QListWidget):
    def __init__(self, parent):
        super(QDropList, self).__init__(parent)
        self.DragDropMode(Qt.QAbstractItemView.DragDropMode.DragOnly)
        self.setAcceptDrops(True)
        self.setDragEnabled(True)

        self.file_list = []

        self.ext_filter = ['.raw']

        self._last_selected_filename = ''

        self.itemSelectionChanged.connect(self.selection_changed)

    def selection_changed(self, *args, **kwargs):
        selected_files = []

        for i in range(len(self)):
            if self.item(i).isSelected():
                selected_files.append(self.file_list[i])

        if len(selected_files) == 1:
            self._last_selected_filename = selected_files[0]
        else:
            pass


    def get_last_selected_file(self)->str:
        """
        리스트박스에서 선택 해제가 되면서 (focus-out) 아이템을 가져올수 없기때문에 별도로 마지막으로 선택한 아이템을 변수에 저장한다.         
        """
        return self._last_selected_filename

    def get_selected_file(self)->str:
        selected_files = []
        assert len(self.file_list) == len(self), 'not same file list and qtlist'
        for i in range(len(self)):
            if self.item(i).isSelected():
                selected_files.append(self.file_list[i])

        # 1개만 선택한 경우에만 유효한 선택으로 가정하고 변수에 저장
        if len(selected_files) == 1:            
            self._last_selected_filename = selected_files[0]            
            return self._last_selected_filename
        else:
            return ''



    def dragMoveEvent(self, e: Qt.QDragMoveEvent) -> None:
        e.accept()

    def dragEnterEvent(self, e):
        print("drag in", QDropList )
        print(type(e.source()))
        e.accept()
        # if type(e.source())==Qt.QTreeWidget:
        #     e.accept()
        # else:
        #     e.ignore()

    def dropEvent(self, e):
        print("drop Event")
        # self.addItem(e.source().currentItem().text(0))
        files = [u.toLocalFile() for u in e.mimeData().urls()]

        for f in files:
            fname = os.path.basename(f)
            ext = os.path.splitext(fname)[1]
            if ext in self.ext_filter:
                self.addItem(Qt.QListWidgetItem(fname))
                self.file_list.append(f)
                # 마지막으로 추가한 아이템 last-item으로 지정
                self._last_selected_filename = f
            else:
                logger = get_runtime_logger()
                logger.info('not supprted format:{} // {}'.format(fname, ext))


class ImageSettingBox(Qt.QWidget):
    image_setting_changed = Qt.pyqtSignal(RawImageParam)
    def __init__(self):
        super(ImageSettingBox, self).__init__()

        label = Qt.QLabel('abc')

        height_label = Qt.QLabel('Height')
        width_label = Qt.QLabel('Width')

        height_edit = Qt.QLineEdit(self)
        height_edit.setValidator(Qt.QIntValidator(1, 5000, self))
        height_edit.setText('0')

        width_edit = Qt.QLineEdit(self)
        width_edit.setValidator(Qt.QIntValidator(1, 5000, self))
        width_edit.setText('0')

        self.litte_endian_checkbox = Qt.QCheckBox('Little-endian byte order')
        self.litte_endian_checkbox.setChecked(True)

        self.white_zero = Qt.QCheckBox('White Zero')
        self.white_zero.setChecked(True)



        self.tables = datatype_table

        self.dtype_box = Qt.QComboBox(self)
        for name in self.tables.keys():
            self.dtype_box.addItem(name)
        # default data type
        default_type = [i for i, v in  enumerate(datatype_table.values()) if v == 'uint16']
        assert len(default_type) == 1
        self.dtype_box.setCurrentIndex(default_type[0])

        height_edit.returnPressed.connect(self.value_changed)
        width_edit.returnPressed.connect(self.value_changed)
        self.dtype_box.currentTextChanged.connect(self.value_changed)
        self.litte_endian_checkbox.stateChanged.connect(self.value_changed)
        self.white_zero.stateChanged.connect(self.value_changed)

        layout = Qt.QGridLayout()
        layout.addWidget(width_label, 0, 0, 1, 1)
        layout.addWidget(width_edit, 0, 1, 1, 1)
        layout.addWidget(height_label, 1, 0, 1, 1)
        layout.addWidget(height_edit, 1, 1, 1, 1)
        layout.addWidget(self.litte_endian_checkbox, 2, 0, 1, 2)
        layout.addWidget(self.white_zero, 3, 0, 1, 2)
        layout.addWidget(self.dtype_box, 4, 0, 1, 2)

        self.height_edit = height_edit
        self.width_edit = width_edit
        # self.resize(400, 200)

        self.setLayout(layout)
        self.setMinimumWidth(150)
        self.setMaximumWidth(200)

    def get_info(self)->RawImageParam:
        param = RawImageParam()
        param.height = int(self.height_edit.text())
        param.width = int(self.width_edit.text())
        checked = self.litte_endian_checkbox.isChecked()
        param.little_endian = checked
        param.white_zero = self.white_zero.isChecked()
        dtype_text = self.dtype_box.currentText()
        param.dtype = datatype_table.get(dtype_text, 'int16')

        return param

    def value_changed(self):
        param = self.get_info()
        # signal emit
        self.image_setting_changed.emit(param)


class XrayViewer(Qt.QWidget):
    def __init__(self, parent, tab):
        super(XrayViewer, self).__init__(parent)
        self.logger = get_runtime_logger()
        self.setAcceptDrops(True)
        self.lab  = Qt.QLabel('abc')
        self.image_view = DicomImageView()
        # self.image_view.add_image('sample.jpg', RawImageParam())
        self.drop_list = QDropList(parent)
        self.drop_list.setMaximumWidth(200)
        # self.drop_list.setGeometry(100, 100, 200, 200)

        layout = Qt.QGridLayout()
        self.toolbar = Qt.QToolBar()
        self.img_set_box = ImageSettingBox()
        layout.addWidget(self.toolbar, 0, 0, 1, 2)
        layout.addWidget(self.img_set_box, 1, 0, 1, 1)
        layout.addWidget(self.drop_list, 2, 0, 1, 1)

        layout.addWidget(self.image_view, 1, 1, 2, 1)

        tab.setLayout(layout)


        self.img_set_box.image_setting_changed.connect(self.changed_image_setting)
        self.drop_list.itemSelectionChanged.connect(self.changed_image_file)

        self.toolbar.addAction(
            create_action("Enhance", "", "","testabc", self, self.prcoss_enghance_iamge))

    def changed_image_file(self):
        # self.drop_list.selectedItems()
        file = self.drop_list.get_last_selected_file()
        param = self.img_set_box.get_info()
        self.logger.debug(param)
        self.image_view.add_image(file, param)

    def update_image_viewer(self, param):
        pass

    def changed_image_setting(self, param:RawImageParam):
        file = self.drop_list.get_last_selected_file()
        param = self.img_set_box.get_info()
        self.logger.debug(param)
        self.image_view.add_image(file, param)

    def prcoss_enghance_iamge(self):
        # get image
        img = self.image_view.get_image()
        logger = get_runtime_logger()
        logger.info('loaded image {} / {}~{} // dtype: {}'.format(img.shape, np.min(img), np.max(img), img.dtype))
        # self.get
        #################################
        # process algorithm (rest)
        prcessed = img + 50
        #################################
        # update image

        self.image_view.update_process_image(prcessed)

        pass

