from PyQt5 import Qt, QtCore
import numpy as np


class Marker(Qt.QGraphicsEllipseItem):
    def __init__(self, pose=[0, 0],  size=[15, 15], slicenum_num=0, view_name=str):
        super(Marker, self).__init__()
        self.size = size

        self.setRect(Qt.QRectF(*pose, *size))
        self.slicenum_num = slicenum_num
        self.view_name = view_name

        # https://python.hotexamples.com/examples/PyQt4.QtGui/QGraphicsEllipseItem/-/python-qgraphicsellipseitem-class-examples.html
        self.setPen(Qt.QPen(Qt.QColor(QtCore.Qt.red), 1, QtCore.Qt.SolidLine))
        # self.setBrush(QtCore.Qt.gray)
        self.setSelected(True)

        self.setFlag(Qt.QGraphicsLineItem.ItemIsSelectable, True)

    def updatePose(self, pose):
        self.setRect(Qt.QRectF(*pose, *self.size))
        # == self.setRect(Qt.QRectF(pose[0], pose[1], self.size[0], self.size[1]))

    def __repr__(self):
        self.rect().x()
        self.rect().y()
        return "pose : {},{} / slice: {} / view_name: {}".format(self.rect().x(), self.rect().y(), self.slicenum_num, self.view_name)

    def from_json(self, some_value):
        # x = some_value['x']
        # y = some_value['y']
        pose = some_value['pose']
        slicenum = some_value['slice']
        view_name = some_value["view_name"]
        self.setRect(Qt.QRectF(*pose, *self.size))
        self.slicenum_num = slicenum
        self.view_name = view_name

    def to_json(self):
        res = {
            # "x": self.rect().x(),
            # "y": self.rect().y(),
            "pose": [self.rect().x(), self.rect().y()],
            "slice": self.slicenum_num,
            "view_name": self.view_name
        }

        return res

    def mousePressEvent(self, event: 'QGraphicsSceneMouseEvent') -> None:
        print('market-presssed')
