#!/usr/bin/env python

"""
  Author: Jared P. Sutton <jpsutton@gmail.com>
  License: LGPL
  Note: I've licensed this code as LGPL because it was a complete translation of the code found here...
    https://github.com/mojocorp/QProgressIndicator

"""

import sys
import time
# from PySide2.QtCore import *
# from PySide2.QtGui import *

# from PyQt5.Qt import *
from PyQt5.Qt import QMainWindow, QApplication, QWidget
from PyQt5 import Qt


class QProgressIndicator(QWidget):
    m_angle = None
    m_timerId = None
    m_delay = None
    m_displayedWhenStopped = None
    m_color = None

    def __init__(self, parent):
        # Call parent class constructor first
        super(QProgressIndicator, self).__init__(parent)

        # Initialize Qt Properties
        self.setProperties()

        # Intialize instance variables
        self.m_angle = 0
        self.m_timerId = -1
        self.m_delay = 40
        self.m_displayedWhenStopped = False
        self.m_color = Qt.Qt.black

        # Set size and focus policy
        # self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.setSizePolicy(Qt.QSizePolicy.Expanding, Qt.QSizePolicy.Expanding)
        # self.setSizePolicy(200, 200)
        self.setFocusPolicy(Qt.Qt.NoFocus)

        # Show the widget
        # self.show()

    def animationDelay(self):
        return self.delay

    def isAnimated(self):
        return (self.m_timerId != -1)

    def isDisplayedWhenStopped(self):
        return self.displayedWhenStopped

    def getColor(self):
        return self.color

    def sizeHint(self):
        return Qt.QSize(20, 20)

    def startAnimation(self):
        self.m_angle = 0

        if self.m_timerId == -1:
            self.m_timerId = self.startTimer(self.m_delay)

    def stopAnimation(self):
        if self.m_timerId != -1:
            self.killTimer(self.m_timerId)

        self.m_timerId = -1
        self.update()

    def setAnimationDelay(self, delay):
        if self.m_timerId != -1:
            self.killTimer(self.m_timerId)

        self.m_delay = delay

        if self.m_timerId != -1:
            self.m_timerId = self.startTimer(self.m_delay)

    def setDisplayedWhenStopped(self, state):
        self.displayedWhenStopped = state
        self.update()

    def setColor(self, color):
        self.m_color = color
        self.update()

    def timerEvent(self, event):
        self.m_angle = (self.m_angle + 30) % 360
        self.update()

    def paintEvent(self, event):
        if (not self.m_displayedWhenStopped) and (not self.isAnimated()):
            return

        width = min(self.width(), self.height())

        painter = Qt.QPainter(self)
        painter.setRenderHint(Qt.QPainter.Antialiasing)

        outerRadius = (width - 1) * 0.5
        innerRadius = (width - 1) * 0.5 * 0.38

        capsuleHeight = outerRadius - innerRadius
        capsuleWidth = capsuleHeight * .23 if (width > 32) else capsuleHeight * .35
        capsuleRadius = capsuleWidth / 2

        for i in range(0, 12):
            color = Qt.QColor(self.m_color)

            if self.isAnimated():
                color.setAlphaF(1.0 - (i / 12.0))
            else:
                color.setAlphaF(0.2)

            painter.setPen(Qt.Qt.NoPen)
            painter.setBrush(color)
            painter.save()
            painter.translate(self.rect().center())
            painter.rotate(self.m_angle - (i * 30.0))
            painter.drawRoundedRect(capsuleWidth * -0.5, (innerRadius + capsuleHeight) * -1, capsuleWidth,
                                    capsuleHeight, capsuleRadius, capsuleRadius)
            painter.restore()

    def setProperties(self):
        self.delay = 100
        pass

    # self.delay = Property(int, self.animationDelay, self.setAnimationDelay)
    # self.displayedWhenStopped = Property(bool, self.isDisplayedWhenStopped, self.setDisplayedWhenStopped)
    # self.color = Property(QColor, self.getColor, self.setColor)


def TestProgressIndicator():
    app = QApplication(sys.argv)
    progress = QProgressIndicator(None)
    progress.setAnimationDelay(70)
    progress.startAnimation()
    # progress.close()
    print("------")
    # Execute the application
    sys.exit(app.exec_())


class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.progress = QProgressIndicator(None)
        self.progress.setAnimationDelay(70)
        # self.setVisible(False)
        # self.progress.startAnimation()
        # progress.close()
        # button = QPushButton()

        layout = Qt.QVBoxLayout()
        self.b1 = Qt.QPushButton("Button1")
        self.b1.setCheckable(True)
        self.b1.toggle()
        # self.b1.clicked.connect(lambda: self.whichbtn(self.b1))
        self.b1.clicked.connect(self.btnstate)
        # tolbar.addAction(self.b1)
        layout.addWidget(self.b1)
        frame = Qt.QFrame()
        frame.setLayout(layout)
        self.setCentralWidget(frame)
        self.show()

    def start(self):
        print("sdfdf")

    def test_dialog(self):
        # QProgressDialog
        numFiles = 100
        progress = Qt.QProgressDialog("Copying files...", "Abort Copy", 0, numFiles, self)
        progress.setWindowModality(Qt.WindowModal)
        import time
        for i in range(numFiles):
            time.sleep(0.05)
            progress.setValue(i)

            if progress.wasCanceled():
                break
            # ... copy one file

        progress.setValue(numFiles)

    def btnstate(self):
        if self.b1.isChecked():
            # self.test_dialog()
            self.progress.stopAnimation()
            self.progress.close()
            # self.progress.close()

            print("stop")
        else:
            self.progress.startAnimation()
            self.progress.show()
            self.calc = External()
            proc = TestProcess()
            self.calc.setparam("test file")
            self.calc.connect(proc.load)
            self.calc.widget = self.progress
            self.calc.finished.connect(self.calc_finished)
            self.calc.start()

            # self.progress.show()

            # for i in range(100):
            #   time.sleep(0.05)
            #   print(i)

    def calc_finished(self):
        print("complete")
        self.progress.stopAnimation()
        self.progress.close()


TIME_LIMIT = 100

class TestProcess(object):
    def __init__(self):
        pass
    def load(self, filename):
        count = 0
        print("------>", filename)
        while count < TIME_LIMIT:
            count += 1
            time.sleep(0.01)
            print("{}/{}".format(count, TIME_LIMIT))


class External(Qt.QThread):
    """
    Runs a counter thread.
    """
    finished = Qt.pyqtSignal()

    def __init__(self):
        super(External, self).__init__()

        self.param = ""
        self.widget = None

    def connect(self, func):
        self.callback = func

    def setprogress(self, widget:QProgressIndicator):
        self.widget = widget

    def setparam(self, param):
        self.param = param

    def run(self):
        self.callback(self.param)
        # self.widget.stopAnimation()
        # self.widget.close()
        self.finished.emit()


def catch_exceptions(t, val, tb):
    # Qt.QMessageBox.critical(None,
    #                                "An exception was raised",
    #                                "Exception type: {}".format(t))
    raise RuntimeError("An exception was raised",
                       "Exception type: {}".format(t))
    exit()
    old_hook(t, val, tb)


if __name__ == "__main__":
    old_hook = sys.excepthook
    sys.excepthook = catch_exceptions

    app = QApplication(sys.argv)
    window = MainWindow()
    sys.exit(app.exec_())

# if __name__ == "__main__":
# TestProgressIndicator()


