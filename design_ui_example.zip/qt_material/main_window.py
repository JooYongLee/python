# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_window.ui'
##
## Created by: Qt User Interface Compiler version 6.5.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWidgets import (QApplication, QCalendarWidget, QComboBox, QDateEdit,
    QDateTimeEdit, QDockWidget, QDoubleSpinBox, QGridLayout,
    QKeySequenceEdit, QLCDNumber, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMainWindow, QMdiArea,
    QMenu, QMenuBar, QPlainTextEdit, QPushButton,
    QSizePolicy, QSpacerItem, QSpinBox, QSplitter,
    QStatusBar, QTabWidget, QTextEdit, QTimeEdit,
    QToolBar, QToolBox, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1501, 806)
        self.actionSubmenu_2 = QAction(MainWindow)
        self.actionSubmenu_2.setObjectName(u"actionSubmenu_2")
        self.actionSubmenu_2.setCheckable(True)
        self.actionSubmenu_3 = QAction(MainWindow)
        self.actionSubmenu_3.setObjectName(u"actionSubmenu_3")
        self.actionSUBSUB = QAction(MainWindow)
        self.actionSUBSUB.setObjectName(u"actionSUBSUB")
        self.actionSUBSUB_2 = QAction(MainWindow)
        self.actionSUBSUB_2.setObjectName(u"actionSUBSUB_2")
        self.actionSUBSUB_3 = QAction(MainWindow)
        self.actionSUBSUB_3.setObjectName(u"actionSUBSUB_3")
        self.actiondissabled = QAction(MainWindow)
        self.actiondissabled.setObjectName(u"actiondissabled")
        self.actiondissabled.setEnabled(False)
        self.actionSubmenu = QAction(MainWindow)
        self.actionSubmenu.setObjectName(u"actionSubmenu")
        self.actionSubmenu.setCheckable(True)
        self.actionSubmenu.setChecked(True)
        self.actionSubmenu_4 = QAction(MainWindow)
        self.actionSubmenu_4.setObjectName(u"actionSubmenu_4")
        self.actionSubmenu_4.setCheckable(True)
        self.actionSubmenu_5 = QAction(MainWindow)
        self.actionSubmenu_5.setObjectName(u"actionSubmenu_5")
        self.actionSubmenu_5.setCheckable(True)
        self.actionSubmenu_5.setEnabled(False)
        self.actionToolbar = QAction(MainWindow)
        self.actionToolbar.setObjectName(u"actionToolbar")
        self.actionSelected = QAction(MainWindow)
        self.actionSelected.setObjectName(u"actionSelected")
        self.actionSelected.setCheckable(True)
        self.actionSelected.setChecked(True)
        self.actionaction = QAction(MainWindow)
        self.actionaction.setObjectName(u"actionaction")
        self.actionaction2 = QAction(MainWindow)
        self.actionaction2.setObjectName(u"actionaction2")
        self.actionaction3 = QAction(MainWindow)
        self.actionaction3.setObjectName(u"actionaction3")
        self.action111 = QAction(MainWindow)
        self.action111.setObjectName(u"action111")
        self.action111.setCheckable(True)
        self.action222 = QAction(MainWindow)
        self.action222.setObjectName(u"action222")
        self.action222.setCheckable(True)
        self.action333 = QAction(MainWindow)
        self.action333.setObjectName(u"action333")
        self.action333.setCheckable(True)
        self.actionsubmenu = QAction(MainWindow)
        self.actionsubmenu.setObjectName(u"actionsubmenu")
        icon = QIcon()
        iconThemeName = u"document-new"
        if QIcon.hasThemeIcon(iconThemeName):
            icon = QIcon.fromTheme(iconThemeName)
        else:
            icon.addFile(u".", QSize(), QIcon.Normal, QIcon.Off)

        self.actionsubmenu.setIcon(icon)
        self.actionsubmenu_2 = QAction(MainWindow)
        self.actionsubmenu_2.setObjectName(u"actionsubmenu_2")
        icon1 = QIcon()
        iconThemeName = u"folder"
        if QIcon.hasThemeIcon(iconThemeName):
            icon1 = QIcon.fromTheme(iconThemeName)
        else:
            icon1.addFile(u".", QSize(), QIcon.Normal, QIcon.Off)

        self.actionsubmenu_2.setIcon(icon1)
        self.actionsubmenu_3 = QAction(MainWindow)
        self.actionsubmenu_3.setObjectName(u"actionsubmenu_3")
        icon2 = QIcon()
        iconThemeName = u"document-save-as"
        if QIcon.hasThemeIcon(iconThemeName):
            icon2 = QIcon.fromTheme(iconThemeName)
        else:
            icon2.addFile(u".", QSize(), QIcon.Normal, QIcon.Off)

        self.actionsubmenu_3.setIcon(icon2)
        self.actionsubmenu_4 = QAction(MainWindow)
        self.actionsubmenu_4.setObjectName(u"actionsubmenu_4")
        icon3 = QIcon()
        iconThemeName = u"document-save"
        if QIcon.hasThemeIcon(iconThemeName):
            icon3 = QIcon.fromTheme(iconThemeName)
        else:
            icon3.addFile(u".", QSize(), QIcon.Normal, QIcon.Off)

        self.actionsubmenu_4.setIcon(icon3)
        self.actionSave_all = QAction(MainWindow)
        self.actionSave_all.setObjectName(u"actionSave_all")
        self.actionClose = QAction(MainWindow)
        self.actionClose.setObjectName(u"actionClose")
        icon4 = QIcon()
        iconThemeName = u"window-close"
        if QIcon.hasThemeIcon(iconThemeName):
            icon4 = QIcon.fromTheme(iconThemeName)
        else:
            icon4.addFile(u".", QSize(), QIcon.Normal, QIcon.Off)

        self.actionClose.setIcon(icon4)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.splitter_2 = QSplitter(self.centralwidget)
        self.splitter_2.setObjectName(u"splitter_2")
        self.splitter_2.setGeometry(QRect(0, 0, 0, 0))
        self.splitter_2.setOrientation(Qt.Vertical)
        self.gridLayout_17 = QGridLayout(self.centralwidget)
        self.gridLayout_17.setObjectName(u"gridLayout_17")
        self.tabWidget_2 = QTabWidget(self.centralwidget)
        self.tabWidget_2.setObjectName(u"tabWidget_2")
        self.tabWidget_2.setTabPosition(QTabWidget.North)
        self.tabWidget_2.setTabsClosable(True)
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.gridLayout_22 = QGridLayout(self.tab)
        self.gridLayout_22.setObjectName(u"gridLayout_22")
        self.toolBox = QToolBox(self.tab)
        self.toolBox.setObjectName(u"toolBox")
        self.page = QWidget()
        self.page.setObjectName(u"page")
        self.page.setGeometry(QRect(0, 0, 689, 306))
        self.gridLayout_14 = QGridLayout(self.page)
        self.gridLayout_14.setObjectName(u"gridLayout_14")
        self.webEngineView = QWebEngineView(self.page)
        self.webEngineView.setObjectName(u"webEngineView")
        self.webEngineView.setUrl(QUrl(u"https://www.python.org/"))

        self.gridLayout_14.addWidget(self.webEngineView, 0, 0, 1, 1)

        self.toolBox.addItem(self.page, u"WebEngine")
        self.page_3 = QWidget()
        self.page_3.setObjectName(u"page_3")
        self.page_3.setGeometry(QRect(0, 0, 1059, 582))
        self.gridLayout_9 = QGridLayout(self.page_3)
        self.gridLayout_9.setObjectName(u"gridLayout_9")
        self.lcdNumber = QLCDNumber(self.page_3)
        self.lcdNumber.setObjectName(u"lcdNumber")
        self.lcdNumber.setSmallDecimalPoint(True)
        self.lcdNumber.setDigitCount(10)
        self.lcdNumber.setSegmentStyle(QLCDNumber.Flat)
        self.lcdNumber.setProperty("value", 3.141592000000000)

        self.gridLayout_9.addWidget(self.lcdNumber, 0, 2, 2, 1)

        self.timeEdit = QTimeEdit(self.page_3)
        self.timeEdit.setObjectName(u"timeEdit")

        self.gridLayout_9.addWidget(self.timeEdit, 0, 0, 1, 1)

        self.dateTimeEdit = QDateTimeEdit(self.page_3)
        self.dateTimeEdit.setObjectName(u"dateTimeEdit")

        self.gridLayout_9.addWidget(self.dateTimeEdit, 1, 0, 1, 1)

        self.dateEdit = QDateEdit(self.page_3)
        self.dateEdit.setObjectName(u"dateEdit")
        self.dateEdit.setDateTime(QDateTime(QDate(1991, 2, 7), QTime(15, 0, 0)))
        self.dateEdit.setCalendarPopup(True)

        self.gridLayout_9.addWidget(self.dateEdit, 0, 1, 1, 1)

        self.keySequenceEdit = QKeySequenceEdit(self.page_3)
        self.keySequenceEdit.setObjectName(u"keySequenceEdit")

        self.gridLayout_9.addWidget(self.keySequenceEdit, 1, 1, 1, 1)

        self.calendarWidget = QCalendarWidget(self.page_3)
        self.calendarWidget.setObjectName(u"calendarWidget")

        self.gridLayout_9.addWidget(self.calendarWidget, 2, 0, 1, 3)

        self.gridLayout_9.setColumnStretch(0, 1)
        self.gridLayout_9.setColumnStretch(1, 1)
        self.gridLayout_9.setColumnStretch(2, 2)
        self.toolBox.addItem(self.page_3, u"Date controls")
        self.page_4 = QWidget()
        self.page_4.setObjectName(u"page_4")
        self.page_4.setGeometry(QRect(0, 0, 672, 318))
        self.gridLayout_21 = QGridLayout(self.page_4)
        self.gridLayout_21.setObjectName(u"gridLayout_21")
        self.label_3 = QLabel(self.page_4)
        self.label_3.setObjectName(u"label_3")
        font = QFont()
        font.setBold(True)
        self.label_3.setFont(font)

        self.gridLayout_21.addWidget(self.label_3, 0, 1, 1, 1)

        self.horizontalSpacer_4 = QSpacerItem(427, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.gridLayout_21.addItem(self.horizontalSpacer_4, 0, 3, 1, 1)

        self.label = QLabel(self.page_4)
        self.label.setObjectName(u"label")
        self.label.setEnabled(False)

        self.gridLayout_21.addWidget(self.label, 0, 2, 1, 1)

        self.gridLayout_4 = QGridLayout()
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.lineEdit_3 = QLineEdit(self.page_4)
        self.lineEdit_3.setObjectName(u"lineEdit_3")

        self.gridLayout_4.addWidget(self.lineEdit_3, 7, 0, 1, 1)

        self.spinBox = QSpinBox(self.page_4)
        self.spinBox.setObjectName(u"spinBox")

        self.gridLayout_4.addWidget(self.spinBox, 4, 0, 1, 1)

        self.comboBox_4 = QComboBox(self.page_4)
        self.comboBox_4.addItem("")
        self.comboBox_4.addItem("")
        self.comboBox_4.addItem("")
        self.comboBox_4.addItem("")
        self.comboBox_4.addItem("")
        self.comboBox_4.setObjectName(u"comboBox_4")
        self.comboBox_4.setEnabled(False)

        self.gridLayout_4.addWidget(self.comboBox_4, 3, 1, 1, 1)

        self.comboBox_6 = QComboBox(self.page_4)
        self.comboBox_6.addItem("")
        self.comboBox_6.addItem("")
        self.comboBox_6.addItem("")
        self.comboBox_6.addItem("")
        self.comboBox_6.addItem("")
        self.comboBox_6.addItem("")
        self.comboBox_6.addItem("")
        self.comboBox_6.setObjectName(u"comboBox_6")
        self.comboBox_6.setEnabled(False)
        self.comboBox_6.setFrame(False)

        self.gridLayout_4.addWidget(self.comboBox_6, 2, 1, 1, 1)

        self.comboBox = QComboBox(self.page_4)
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setEditable(True)

        self.gridLayout_4.addWidget(self.comboBox, 0, 0, 1, 1)

        self.doubleSpinBox = QDoubleSpinBox(self.page_4)
        self.doubleSpinBox.setObjectName(u"doubleSpinBox")

        self.gridLayout_4.addWidget(self.doubleSpinBox, 5, 0, 1, 1)

        self.comboBox_7 = QComboBox(self.page_4)
        self.comboBox_7.addItem("")
        self.comboBox_7.addItem("")
        self.comboBox_7.addItem("")
        self.comboBox_7.addItem("")
        self.comboBox_7.addItem("")
        self.comboBox_7.setObjectName(u"comboBox_7")
        self.comboBox_7.setEditable(True)

        self.gridLayout_4.addWidget(self.comboBox_7, 1, 0, 1, 1)

        self.lineEdit = QLineEdit(self.page_4)
        self.lineEdit.setObjectName(u"lineEdit")

        self.gridLayout_4.addWidget(self.lineEdit, 6, 0, 1, 1)

        self.doubleSpinBox_2 = QDoubleSpinBox(self.page_4)
        self.doubleSpinBox_2.setObjectName(u"doubleSpinBox_2")
        self.doubleSpinBox_2.setEnabled(False)

        self.gridLayout_4.addWidget(self.doubleSpinBox_2, 5, 1, 1, 1)

        self.spinBox_2 = QSpinBox(self.page_4)
        self.spinBox_2.setObjectName(u"spinBox_2")
        self.spinBox_2.setEnabled(False)

        self.gridLayout_4.addWidget(self.spinBox_2, 4, 1, 1, 1)

        self.comboBox_3 = QComboBox(self.page_4)
        self.comboBox_3.addItem("")
        self.comboBox_3.addItem("")
        self.comboBox_3.addItem("")
        self.comboBox_3.addItem("")
        self.comboBox_3.addItem("")
        self.comboBox_3.addItem("")
        self.comboBox_3.setObjectName(u"comboBox_3")
        self.comboBox_3.setEnabled(False)
        self.comboBox_3.setEditable(True)

        self.gridLayout_4.addWidget(self.comboBox_3, 0, 1, 1, 1)

        self.lineEdit_2 = QLineEdit(self.page_4)
        self.lineEdit_2.setObjectName(u"lineEdit_2")
        self.lineEdit_2.setEnabled(False)

        self.gridLayout_4.addWidget(self.lineEdit_2, 6, 1, 1, 1)

        self.comboBox_2 = QComboBox(self.page_4)
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.setObjectName(u"comboBox_2")

        self.gridLayout_4.addWidget(self.comboBox_2, 3, 0, 1, 1)

        self.comboBox_5 = QComboBox(self.page_4)
        self.comboBox_5.addItem("")
        self.comboBox_5.addItem("")
        self.comboBox_5.addItem("")
        self.comboBox_5.addItem("")
        self.comboBox_5.addItem("")
        self.comboBox_5.addItem("")
        self.comboBox_5.addItem("")
        self.comboBox_5.setObjectName(u"comboBox_5")
        self.comboBox_5.setFrame(False)

        self.gridLayout_4.addWidget(self.comboBox_5, 2, 0, 1, 1)

        self.lineEdit_4 = QLineEdit(self.page_4)
        self.lineEdit_4.setObjectName(u"lineEdit_4")
        self.lineEdit_4.setEnabled(False)

        self.gridLayout_4.addWidget(self.lineEdit_4, 7, 1, 1, 1)


        self.gridLayout_21.addLayout(self.gridLayout_4, 2, 0, 1, 4)

        self.label_2 = QLabel(self.page_4)
        self.label_2.setObjectName(u"label_2")

        self.gridLayout_21.addWidget(self.label_2, 0, 0, 1, 1)

        self.gridLayout_7 = QGridLayout()
        self.gridLayout_7.setObjectName(u"gridLayout_7")
        self.pushButton_18 = QPushButton(self.page_4)
        self.pushButton_18.setObjectName(u"pushButton_18")

        self.gridLayout_7.addWidget(self.pushButton_18, 0, 0, 1, 1)

        self.pushButton_22 = QPushButton(self.page_4)
        self.pushButton_22.setObjectName(u"pushButton_22")
        self.pushButton_22.setFlat(True)

        self.gridLayout_7.addWidget(self.pushButton_22, 1, 1, 1, 1)

        self.pushButton_19 = QPushButton(self.page_4)
        self.pushButton_19.setObjectName(u"pushButton_19")

        self.gridLayout_7.addWidget(self.pushButton_19, 0, 2, 1, 1)

        self.pushButton_21 = QPushButton(self.page_4)
        self.pushButton_21.setObjectName(u"pushButton_21")
        self.pushButton_21.setFlat(True)

        self.gridLayout_7.addWidget(self.pushButton_21, 1, 2, 1, 1)

        self.pushButton_20 = QPushButton(self.page_4)
        self.pushButton_20.setObjectName(u"pushButton_20")

        self.gridLayout_7.addWidget(self.pushButton_20, 0, 1, 1, 1)

        self.pushButton_23 = QPushButton(self.page_4)
        self.pushButton_23.setObjectName(u"pushButton_23")
        self.pushButton_23.setFlat(True)

        self.gridLayout_7.addWidget(self.pushButton_23, 1, 0, 1, 1)


        self.gridLayout_21.addLayout(self.gridLayout_7, 1, 0, 1, 4)

        self.toolBox.addItem(self.page_4, u"Inputs")

        self.gridLayout_22.addWidget(self.toolBox, 0, 0, 2, 2)

        self.tabWidget_2.addTab(self.tab, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.gridLayout_23 = QGridLayout(self.tab_2)
        self.gridLayout_23.setObjectName(u"gridLayout_23")
        self.mdiArea = QMdiArea(self.tab_2)
        self.mdiArea.setObjectName(u"mdiArea")

        self.gridLayout_23.addWidget(self.mdiArea, 0, 0, 1, 1)

        self.tabWidget_2.addTab(self.tab_2, "")

        self.gridLayout_17.addWidget(self.tabWidget_2, 0, 0, 2, 1)

        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.dockWidget_6 = QDockWidget(MainWindow)
        self.dockWidget_6.setObjectName(u"dockWidget_6")
        self.dockWidgetContents_5 = QWidget()
        self.dockWidgetContents_5.setObjectName(u"dockWidgetContents_5")
        self.gridLayout_20 = QGridLayout(self.dockWidgetContents_5)
        self.gridLayout_20.setObjectName(u"gridLayout_20")
        self.listWidget = QListWidget(self.dockWidgetContents_5)
        __qlistwidgetitem = QListWidgetItem(self.listWidget)
        __qlistwidgetitem.setCheckState(Qt.Checked);
        __qlistwidgetitem.setFlags(Qt.ItemIsSelectable|Qt.ItemIsEditable|Qt.ItemIsDragEnabled|Qt.ItemIsUserCheckable|Qt.ItemIsEnabled);
        __qlistwidgetitem1 = QListWidgetItem(self.listWidget)
        __qlistwidgetitem1.setCheckState(Qt.Unchecked);
        __qlistwidgetitem2 = QListWidgetItem(self.listWidget)
        __qlistwidgetitem2.setCheckState(Qt.PartiallyChecked);
        __qlistwidgetitem3 = QListWidgetItem(self.listWidget)
        __qlistwidgetitem3.setCheckState(Qt.Checked);
        __qlistwidgetitem3.setFlags(Qt.ItemIsSelectable|Qt.ItemIsDragEnabled|Qt.ItemIsUserCheckable);
        __qlistwidgetitem4 = QListWidgetItem(self.listWidget)
        __qlistwidgetitem4.setCheckState(Qt.Unchecked);
        __qlistwidgetitem4.setFlags(Qt.ItemIsSelectable|Qt.ItemIsDragEnabled|Qt.ItemIsUserCheckable);
        __qlistwidgetitem5 = QListWidgetItem(self.listWidget)
        __qlistwidgetitem5.setCheckState(Qt.PartiallyChecked);
        __qlistwidgetitem5.setFlags(Qt.ItemIsSelectable|Qt.ItemIsDragEnabled|Qt.ItemIsUserCheckable);
        QListWidgetItem(self.listWidget)
        __qlistwidgetitem6 = QListWidgetItem(self.listWidget)
        __qlistwidgetitem6.setFlags(Qt.ItemIsSelectable|Qt.ItemIsDragEnabled|Qt.ItemIsUserCheckable);
        self.listWidget.setObjectName(u"listWidget")

        self.gridLayout_20.addWidget(self.listWidget, 0, 0, 1, 1)

        self.dockWidget_6.setWidget(self.dockWidgetContents_5)
        MainWindow.addDockWidget(Qt.RightDockWidgetArea, self.dockWidget_6)
        self.toolBar = QToolBar(MainWindow)
        self.toolBar.setObjectName(u"toolBar")
        self.toolBar.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        MainWindow.addToolBar(Qt.TopToolBarArea, self.toolBar)
        self.toolBar_vertical = QToolBar(MainWindow)
        self.toolBar_vertical.setObjectName(u"toolBar_vertical")
        MainWindow.addToolBar(Qt.LeftToolBarArea, self.toolBar_vertical)
        self.dockWidget = QDockWidget(MainWindow)
        self.dockWidget.setObjectName(u"dockWidget")
        self.dockWidgetContents = QWidget()
        self.dockWidgetContents.setObjectName(u"dockWidgetContents")
        self.gridLayout_26 = QGridLayout(self.dockWidgetContents)
        self.gridLayout_26.setObjectName(u"gridLayout_26")
        self.textEdit = QTextEdit(self.dockWidgetContents)
        self.textEdit.setObjectName(u"textEdit")

        self.gridLayout_26.addWidget(self.textEdit, 0, 0, 1, 1)

        self.plainTextEdit = QPlainTextEdit(self.dockWidgetContents)
        self.plainTextEdit.setObjectName(u"plainTextEdit")

        self.gridLayout_26.addWidget(self.plainTextEdit, 1, 0, 1, 1)

        self.dockWidget.setWidget(self.dockWidgetContents)
        MainWindow.addDockWidget(Qt.RightDockWidgetArea, self.dockWidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1501, 22))
        self.menumenu = QMenu(self.menubar)
        self.menumenu.setObjectName(u"menumenu")
        self.menuSubmenu = QMenu(self.menumenu)
        self.menuSubmenu.setObjectName(u"menuSubmenu")
        self.menumenu2 = QMenu(self.menubar)
        self.menumenu2.setObjectName(u"menumenu2")
        self.menumenu_disabled = QMenu(self.menubar)
        self.menumenu_disabled.setObjectName(u"menumenu_disabled")
        self.menumenu_disabled.setEnabled(False)
        self.menuStyles = QMenu(self.menubar)
        self.menuStyles.setObjectName(u"menuStyles")
        self.menuDensity = QMenu(self.menubar)
        self.menuDensity.setObjectName(u"menuDensity")
        self.menuMenu_with_icons = QMenu(self.menubar)
        self.menuMenu_with_icons.setObjectName(u"menuMenu_with_icons")
        self.menuMenu3 = QMenu(self.menubar)
        self.menuMenu3.setObjectName(u"menuMenu3")
        MainWindow.setMenuBar(self.menubar)
        QWidget.setTabOrder(self.tabWidget_2, self.pushButton_18)
        QWidget.setTabOrder(self.pushButton_18, self.pushButton_20)
        QWidget.setTabOrder(self.pushButton_20, self.pushButton_19)
        QWidget.setTabOrder(self.pushButton_19, self.pushButton_23)
        QWidget.setTabOrder(self.pushButton_23, self.pushButton_22)
        QWidget.setTabOrder(self.pushButton_22, self.pushButton_21)
        QWidget.setTabOrder(self.pushButton_21, self.comboBox)
        QWidget.setTabOrder(self.comboBox, self.comboBox_7)
        QWidget.setTabOrder(self.comboBox_7, self.comboBox_5)
        QWidget.setTabOrder(self.comboBox_5, self.comboBox_2)
        QWidget.setTabOrder(self.comboBox_2, self.spinBox)
        QWidget.setTabOrder(self.spinBox, self.doubleSpinBox)
        QWidget.setTabOrder(self.doubleSpinBox, self.lineEdit)
        QWidget.setTabOrder(self.lineEdit, self.lineEdit_3)
        QWidget.setTabOrder(self.lineEdit_3, self.comboBox_3)
        QWidget.setTabOrder(self.comboBox_3, self.comboBox_6)
        QWidget.setTabOrder(self.comboBox_6, self.comboBox_4)
        QWidget.setTabOrder(self.comboBox_4, self.spinBox_2)
        QWidget.setTabOrder(self.spinBox_2, self.doubleSpinBox_2)
        QWidget.setTabOrder(self.doubleSpinBox_2, self.lineEdit_2)
        QWidget.setTabOrder(self.lineEdit_2, self.listWidget)
        QWidget.setTabOrder(self.listWidget, self.textEdit)
        QWidget.setTabOrder(self.textEdit, self.plainTextEdit)
        QWidget.setTabOrder(self.plainTextEdit, self.timeEdit)
        QWidget.setTabOrder(self.timeEdit, self.dateEdit)
        QWidget.setTabOrder(self.dateEdit, self.dateTimeEdit)
        QWidget.setTabOrder(self.dateTimeEdit, self.keySequenceEdit)
        QWidget.setTabOrder(self.keySequenceEdit, self.calendarWidget)
        QWidget.setTabOrder(self.calendarWidget, self.lineEdit_4)

        self.toolBar.addAction(self.actionToolbar)
        self.toolBar.addAction(self.actionSelected)
        self.toolBar.addSeparator()
        self.toolBar.addAction(self.actionaction)
        self.toolBar.addAction(self.actionaction2)
        self.toolBar.addAction(self.actionaction3)
        self.toolBar_vertical.addAction(self.actionToolbar)
        self.toolBar_vertical.addAction(self.actionSelected)
        self.menubar.addAction(self.menuStyles.menuAction())
        self.menubar.addAction(self.menuDensity.menuAction())
        self.menubar.addAction(self.menumenu.menuAction())
        self.menubar.addAction(self.menumenu2.menuAction())
        self.menubar.addAction(self.menuMenu_with_icons.menuAction())
        self.menubar.addAction(self.menumenu_disabled.menuAction())
        self.menubar.addAction(self.menuMenu3.menuAction())
        self.menumenu.addAction(self.menuSubmenu.menuAction())
        self.menumenu.addAction(self.actionSubmenu_2)
        self.menumenu.addSeparator()
        self.menumenu.addAction(self.actionSubmenu_3)
        self.menumenu.addAction(self.actiondissabled)
        self.menuSubmenu.addAction(self.actionSUBSUB)
        self.menuSubmenu.addAction(self.actionSUBSUB_2)
        self.menuSubmenu.addSeparator()
        self.menuSubmenu.addAction(self.actionSUBSUB_3)
        self.menumenu2.addAction(self.actionSubmenu)
        self.menumenu2.addAction(self.actionSubmenu_4)
        self.menumenu2.addAction(self.actionSubmenu_5)
        self.menuMenu_with_icons.addAction(self.actionsubmenu)
        self.menuMenu_with_icons.addAction(self.actionsubmenu_2)
        self.menuMenu_with_icons.addSeparator()
        self.menuMenu_with_icons.addAction(self.actionsubmenu_4)
        self.menuMenu_with_icons.addAction(self.actionsubmenu_3)
        self.menuMenu_with_icons.addAction(self.actionSave_all)
        self.menuMenu_with_icons.addSeparator()
        self.menuMenu_with_icons.addAction(self.actionClose)

        self.retranslateUi(MainWindow)

        self.tabWidget_2.setCurrentIndex(0)
        self.toolBox.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Qt Material", None))
        self.actionSubmenu_2.setText(QCoreApplication.translate("MainWindow", u"Submenu", None))
        self.actionSubmenu_3.setText(QCoreApplication.translate("MainWindow", u"Submenu", None))
        self.actionSUBSUB.setText(QCoreApplication.translate("MainWindow", u"SUBSUB", None))
        self.actionSUBSUB_2.setText(QCoreApplication.translate("MainWindow", u"SUBSUB", None))
        self.actionSUBSUB_3.setText(QCoreApplication.translate("MainWindow", u"SUBSUB", None))
        self.actiondissabled.setText(QCoreApplication.translate("MainWindow", u"dissabled", None))
        self.actionSubmenu.setText(QCoreApplication.translate("MainWindow", u"Submenu", None))
        self.actionSubmenu_4.setText(QCoreApplication.translate("MainWindow", u"Submenu", None))
        self.actionSubmenu_5.setText(QCoreApplication.translate("MainWindow", u"Submenu", None))
        self.actionToolbar.setText(QCoreApplication.translate("MainWindow", u"Qt Material Theme", None))
#if QT_CONFIG(tooltip)
        self.actionToolbar.setToolTip(QCoreApplication.translate("MainWindow", u"Qt Material Theme", None))
#endif // QT_CONFIG(tooltip)
        self.actionSelected.setText(QCoreApplication.translate("MainWindow", u"Selected", None))
        self.actionaction.setText(QCoreApplication.translate("MainWindow", u"action", None))
        self.actionaction2.setText(QCoreApplication.translate("MainWindow", u"action2", None))
        self.actionaction3.setText(QCoreApplication.translate("MainWindow", u"action3", None))
        self.action111.setText(QCoreApplication.translate("MainWindow", u"111", None))
        self.action222.setText(QCoreApplication.translate("MainWindow", u"222", None))
        self.action333.setText(QCoreApplication.translate("MainWindow", u"333", None))
        self.actionsubmenu.setText(QCoreApplication.translate("MainWindow", u"New...", None))
        self.actionsubmenu_2.setText(QCoreApplication.translate("MainWindow", u"Open...", None))
        self.actionsubmenu_3.setText(QCoreApplication.translate("MainWindow", u"Save as...", None))
        self.actionsubmenu_4.setText(QCoreApplication.translate("MainWindow", u"Save", None))
        self.actionSave_all.setText(QCoreApplication.translate("MainWindow", u"Save all", None))
        self.actionClose.setText(QCoreApplication.translate("MainWindow", u"Close", None))
        self.toolBox.setItemText(self.toolBox.indexOf(self.page), QCoreApplication.translate("MainWindow", u"WebEngine", None))
        self.toolBox.setItemText(self.toolBox.indexOf(self.page_3), QCoreApplication.translate("MainWindow", u"Date controls", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Material theme", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Material theme", None))
        self.lineEdit_3.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Placeholder text", None))
        self.comboBox_4.setItemText(0, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox_4.setItemText(1, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox_4.setItemText(2, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox_4.setItemText(3, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox_4.setItemText(4, QCoreApplication.translate("MainWindow", u"New Item", None))

        self.comboBox_6.setItemText(0, QCoreApplication.translate("MainWindow", u"New Item1", None))
        self.comboBox_6.setItemText(1, QCoreApplication.translate("MainWindow", u"New Item2", None))
        self.comboBox_6.setItemText(2, QCoreApplication.translate("MainWindow", u"New Item3", None))
        self.comboBox_6.setItemText(3, QCoreApplication.translate("MainWindow", u"New Item4", None))
        self.comboBox_6.setItemText(4, QCoreApplication.translate("MainWindow", u"New Item5", None))
        self.comboBox_6.setItemText(5, QCoreApplication.translate("MainWindow", u"New Item6", None))
        self.comboBox_6.setItemText(6, QCoreApplication.translate("MainWindow", u"New Item7", None))

        self.comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox.setItemText(4, QCoreApplication.translate("MainWindow", u"New Item", None))

        self.comboBox.setCurrentText(QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox_7.setItemText(0, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox_7.setItemText(1, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox_7.setItemText(2, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox_7.setItemText(3, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox_7.setItemText(4, QCoreApplication.translate("MainWindow", u"New Item", None))

        self.lineEdit.setText(QCoreApplication.translate("MainWindow", u"Lorem ipsum dolor sit amet", None))
        self.comboBox_3.setItemText(0, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox_3.setItemText(1, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox_3.setItemText(2, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox_3.setItemText(3, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox_3.setItemText(4, QCoreApplication.translate("MainWindow", u"New Item", None))
        self.comboBox_3.setItemText(5, QCoreApplication.translate("MainWindow", u"New Item", None))

        self.lineEdit_2.setText(QCoreApplication.translate("MainWindow", u"Lorem ipsum dolor sit amet", None))
        self.comboBox_2.setItemText(0, QCoreApplication.translate("MainWindow", u"New Item1", None))
        self.comboBox_2.setItemText(1, QCoreApplication.translate("MainWindow", u"New Item2", None))
        self.comboBox_2.setItemText(2, QCoreApplication.translate("MainWindow", u"New Item3", None))
        self.comboBox_2.setItemText(3, QCoreApplication.translate("MainWindow", u"New Item4", None))
        self.comboBox_2.setItemText(4, QCoreApplication.translate("MainWindow", u"New Item5", None))
        self.comboBox_2.setItemText(5, QCoreApplication.translate("MainWindow", u"New Item6", None))
        self.comboBox_2.setItemText(6, QCoreApplication.translate("MainWindow", u"New Item7", None))

        self.comboBox_5.setItemText(0, QCoreApplication.translate("MainWindow", u"New Item1", None))
        self.comboBox_5.setItemText(1, QCoreApplication.translate("MainWindow", u"New Item2", None))
        self.comboBox_5.setItemText(2, QCoreApplication.translate("MainWindow", u"New Item3", None))
        self.comboBox_5.setItemText(3, QCoreApplication.translate("MainWindow", u"New Item4", None))
        self.comboBox_5.setItemText(4, QCoreApplication.translate("MainWindow", u"New Item5", None))
        self.comboBox_5.setItemText(5, QCoreApplication.translate("MainWindow", u"New Item6", None))
        self.comboBox_5.setItemText(6, QCoreApplication.translate("MainWindow", u"New Item7", None))

        self.lineEdit_4.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Placeholder text", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Material theme", None))
        self.pushButton_18.setText(QCoreApplication.translate("MainWindow", u"Danger", None))
        self.pushButton_18.setProperty("class", QCoreApplication.translate("MainWindow", u"danger", None))
        self.pushButton_22.setText(QCoreApplication.translate("MainWindow", u"Success", None))
        self.pushButton_22.setProperty("class", QCoreApplication.translate("MainWindow", u"success", None))
        self.pushButton_19.setText(QCoreApplication.translate("MainWindow", u"Warning", None))
        self.pushButton_19.setProperty("class", QCoreApplication.translate("MainWindow", u"warning", None))
        self.pushButton_21.setText(QCoreApplication.translate("MainWindow", u"Warning", None))
        self.pushButton_21.setProperty("class", QCoreApplication.translate("MainWindow", u"warning", None))
        self.pushButton_20.setText(QCoreApplication.translate("MainWindow", u"Success", None))
        self.pushButton_20.setProperty("class", QCoreApplication.translate("MainWindow", u"success", None))
        self.pushButton_23.setText(QCoreApplication.translate("MainWindow", u"Danger", None))
        self.pushButton_23.setProperty("class", QCoreApplication.translate("MainWindow", u"danger", None))
        self.toolBox.setItemText(self.toolBox.indexOf(self.page_4), QCoreApplication.translate("MainWindow", u"Inputs", None))
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.tab), QCoreApplication.translate("MainWindow", u"Page", None))
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.tab_2), QCoreApplication.translate("MainWindow", u"Long Page Name", None))
        self.dockWidget_6.setWindowTitle(QCoreApplication.translate("MainWindow", u"Top Dock", None))

        __sortingEnabled = self.listWidget.isSortingEnabled()
        self.listWidget.setSortingEnabled(False)
        ___qlistwidgetitem = self.listWidget.item(0)
        ___qlistwidgetitem.setText(QCoreApplication.translate("MainWindow", u"New Item (editable)", None));
        ___qlistwidgetitem1 = self.listWidget.item(1)
        ___qlistwidgetitem1.setText(QCoreApplication.translate("MainWindow", u"New Item", None));
        ___qlistwidgetitem2 = self.listWidget.item(2)
        ___qlistwidgetitem2.setText(QCoreApplication.translate("MainWindow", u"New Item", None));
        ___qlistwidgetitem3 = self.listWidget.item(3)
        ___qlistwidgetitem3.setText(QCoreApplication.translate("MainWindow", u"New Item", None));
        ___qlistwidgetitem4 = self.listWidget.item(4)
        ___qlistwidgetitem4.setText(QCoreApplication.translate("MainWindow", u"New Item", None));
        ___qlistwidgetitem5 = self.listWidget.item(5)
        ___qlistwidgetitem5.setText(QCoreApplication.translate("MainWindow", u"New Item", None));
        ___qlistwidgetitem6 = self.listWidget.item(6)
        ___qlistwidgetitem6.setText(QCoreApplication.translate("MainWindow", u"New Item", None));
        ___qlistwidgetitem7 = self.listWidget.item(7)
        ___qlistwidgetitem7.setText(QCoreApplication.translate("MainWindow", u"New Item", None));
        self.listWidget.setSortingEnabled(__sortingEnabled)

        self.toolBar.setWindowTitle(QCoreApplication.translate("MainWindow", u"toolBar", None))
        self.toolBar_vertical.setWindowTitle(QCoreApplication.translate("MainWindow", u"toolBar_2", None))
        self.dockWidget.setWindowTitle(QCoreApplication.translate("MainWindow", u"Right Doc", None))
        self.textEdit.setMarkdown(QCoreApplication.translate("MainWindow", u"textEdit Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do\n"
"eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim\n"
"veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\n"
"consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\n"
"cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\n"
"proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n"
"\n"
"", None))
        self.textEdit.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'\ub9d1\uc740 \uace0\ub515'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:6px; margin-bottom:6px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Noto Sans'; font-size:10pt;\">textEdit Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat n"
                        "ulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p></body></html>", None))
        self.plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"plainTextEdit\n"
"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.", None))
        self.menumenu.setTitle(QCoreApplication.translate("MainWindow", u"Menu", None))
        self.menuSubmenu.setTitle(QCoreApplication.translate("MainWindow", u"Submenu", None))
        self.menumenu2.setTitle(QCoreApplication.translate("MainWindow", u"Menu2", None))
        self.menumenu_disabled.setTitle(QCoreApplication.translate("MainWindow", u"Menu3 disabled", None))
        self.menuStyles.setTitle(QCoreApplication.translate("MainWindow", u"Styles", None))
        self.menuDensity.setTitle(QCoreApplication.translate("MainWindow", u"Density", None))
        self.menuMenu_with_icons.setTitle(QCoreApplication.translate("MainWindow", u"Menu with icons", None))
        self.menuMenu3.setTitle(QCoreApplication.translate("MainWindow", u"Menu4", None))
    # retranslateUi

