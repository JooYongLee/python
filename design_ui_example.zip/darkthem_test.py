import sys

from PySide6.QtWidgets import QApplication, QMainWindow, QPushButton, QComboBox
from PySide6.QtWidgets import QApplication, QMainWindow, QPushButton, QStyle

# from PySide6 import QtWidgets
from PySide6.QtWidgets import QListWidget, QVBoxLayout, QWidget
import qdarktheme

def list_combo_box():
    # qdarktheme.enable_hi_dpi()
    app = QApplication(sys.argv)
    app.setStyleSheet(qdarktheme.load_stylesheet())
    # Apply the complete dark theme to your Qt App.
    qdarktheme.setup_theme("light")

    layout = QVBoxLayout()
    main_win = QMainWindow()
    push_button = QPushButton("PyQtDarkTheme!!")

    combo_box = QComboBox()
    combo_box.addItems(qdarktheme.get_themes())
    combo_box.currentTextChanged.connect(qdarktheme.setup_theme)

    listwidget = QListWidget()
    listwidget.addItem("test")
    listwidget.addItem("abc")
    listwidget.addItem("def")
    layout.addWidget(push_button)
    layout.addWidget(combo_box)
    layout.addWidget(listwidget)

    centeral_widget = QWidget()
    centeral_widget.setLayout(layout)
    main_win.setCentralWidget(centeral_widget)

    app.setPalette(qdarktheme.load_palette())
    main_win.show()

    app.exec()

def use_standard_icons():
    app = QApplication(sys.argv)
    qdarktheme.setup_theme()
    app.setStyleSheet(qdarktheme.load_stylesheet())

    main_win = QMainWindow()
    save_pixmap = QStyle.StandardPixmap.SP_DialogSaveButton
    save_icon = main_win.style().standardIcon(save_pixmap)
    # QStyle.StandardPixmap.S
    # QStyle.StandardPixmap.
    push_button = QPushButton("Save")
    push_button.setIcon(save_icon)
    main_win.setCentralWidget(push_button)

    main_win.show()

    app.exec()

def apply_style_sheet():
    app = QApplication(sys.argv)
    # Apply stylesheet as "dark" theme
    app.setStyleSheet(qdarktheme.load_stylesheet())

    main_win = QMainWindow()
    push_button = QPushButton("PyQtDarkTheme!!")
    main_win.setCentralWidget(push_button)

    main_win.show()

    app.exec()


def apply_dark_pallte():
    app = QApplication(sys.argv)
    main_win = QMainWindow()
    push_button = QPushButton("PyQtDarkTheme!!")
    main_win.setCentralWidget(push_button)

    # Apply dark theme
    app.setPalette(qdarktheme.load_palette())

    main_win.show()

    app.exec()

# apply_dark_pallte()
list_combo_box()
# use_standard_icons()
# apply_style_sheet()