# from mytest.mymain import test_main2
from PyOneDark_Qt_Widgets.mytest.mymain import test_main2
test_main2()