import sys
from PySide6 import QtWidgets
from PySide6.QtUiTools import QUiLoader
from PySide6.QtGui import QPixmap
import vtk
import numpy as np


from packaging import version
vtk_version = vtk.vtkVersion().GetVTKVersion()
if version.parse(vtk_version) > version.parse('9.0.0'):
    import vtkmodules.all as vtk
    from vtkmodules.util import numpy_support
    from vtkmodules.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor
else:
    from vtk.util import numpy_support
    from vtk.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor


from .vtk_interaction import MyInteractorStyle
from . import vtk_utils
from .MainWindow import Ui_MainWindow
from .. import qtutils

def test_main():
    loader = QUiLoader()

    def mainwindow_setup(w):
        w.setWindowTitle("MainWindow Title")

    app = QtWidgets.QApplication(sys.argv)

    window = loader.load("mytest.ui", None)
    mainwindow_setup(window)
    window.show()
    app.exec_()


class ImageWidget(QtWidgets.QGraphicsScene):
    # update_voi_signal = Qt.pyqtSignal() # not used
    # focus_changed_signal = Qt.pyqtSignal() # focus
    # boundary_changed_signal = Qt.pyqtSignal()

    def __init__(self, viewwidget=None):
        # assert mode in [CORONAL, AXIAL, SAGITTAL]
        super(ImageWidget, self).__init__()
        # self.list_widget = list_slicer
        # self.drawing_mask = False

        # self.name = VIEW_NAMES[mode]
        # self.mode = mode
        self.viewWidget = viewwidget or QtWidgets.QGraphicsView()

        self.viewWidget.setScene(self)

        # mouseMove 이벤트 On?
        self.viewWidget.setMouseTracking(True)

        # 이미지 시작시 초기화할 해상도 크기 설정
        # empty = np.zeros([300, 300, 3], dtype=np.uint8)


        # 이미지 추가
        self.pixmap = None # type:QtWidgets.QGraphicsPixmapItem

        self._update_resize_iamge()
        # QtWidgets.QGraphicsPixmapItem()


    def _update_resize_iamge(self):
        if self.pixmap is not None:
            self.removeItem(self.pixmap)
        ratio = 0.6
        w, h = self.viewWidget.width(), self.viewWidget.height()
        w = int(ratio * w)
        h = int(ratio * h)
        empty = np.zeros([h, w, 3], dtype=np.uint8) * 255
        piximage = QPixmap(qtutils.numpy2qimage(empty))
        self.pixmap = QtWidgets.QGraphicsPixmapItem()
        self.pixmap.setPixmap(piximage)
        self.addItem(self.pixmap)

        print(self.viewWidget.geometry(), self.sceneRect(), self.pixmap.scenePos())


    def resizeEvent(self, ev):
        # print("resiazed", ImageWidget, ev,
        #       self.viewWidget.size())
        self._update_resize_iamge()


    # def _resize_image(self):


        empty = np.zeros([300, 300, 3], dtype=np.uint8) * 255

        # self.viewWidget.        #
        #         # self.parent().re
        #         # self.viewWidget.reresized



class VtkRendererWidget(QVTKRenderWindowInteractor):
    def __init__(self, parent=None):
        super(VtkRendererWidget, self).__init__(parent)
        self._parent = parent
        # self.widget = QVTKRenderWindowInteractor()
        self.iren = self.GetRenderWindow().GetInteractor()
        self.ren = vtk.vtkRenderer()
        self.ren.SetBackground(0.1, 0.2, 0.3)

        colors = vtk.vtkNamedColors()
        self.ren.GradientBackgroundOn();

        def get_color(name):
            c = colors.GetColor3d(name)
            return (c.GetRed(), c.GetGreen(), c.GetBlue())

        
        # colors.GetColor3d("Banana").GetData()[0]
        # self.ren.Ba
        self.ren.SetBackground(*get_color('banana'));
        self.ren.SetBackground2(*get_color("Tomato"));


        self.renWin = self.iren.GetRenderWindow()
        self.renWin.AddRenderer(self.ren)
        # self.renWin.SetSize(parent.size().width(), parent.size().height())
        self.iren.SetInteractorStyle(MyInteractorStyle(None))
        # self.layout.addWidget(self.vtkWidget)
        # self.verticalLayout.addWidget(self.vtkWidget)
        # self.ren.SetSize(500, 500)
        # self.renWin.SetSize(500, 500)
        # self.Initialize()
        # self.Start()

    # def resizeEvent(self, ev):
    #     # print('render:parent {}/ rendere {}'.format(self.parent().size(), self.renWin.GetSize()))
    #     # super(VtkRendererWidget, self).resizeEvent(ev)
    #
    #     scale = self._getPixelRatio()
    #     w = int(round(scale*self.parent().width()))
    #     h = int(round(scale*self.parent().height()))
    #     self._RenderWindow.SetDPI(int(round(72*scale)))
    #     # vtk.vtkRenderWindow.SetSize(self._RenderWindow, w, h)
    #     self.renWin.SetSize(w, h)
    #     self._Iren.SetSize(w, h)
    #     self._Iren.ConfigureEvent()
    #     self.update()
    #     print('resize event', w, h)
    #     # self.show()
    #     # self.contourWidget.EnabledOn()

    def add_polydata(self, filename):
        poly = vtk_utils.read_stl(filename)
        actor = vtk_utils.polydata2actor(poly)
        self.ren.AddActor(actor)
        self.renWin.Render()
        # self.ren.Render()
        # self.Render()

class MainWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()

        self.setupUi(self)

        self.vtk_widget = VtkRendererWidget()
        self.verticalLayout.addWidget(self.vtk_widget)
        # self.vtk_widget
        filename = 'Stanford_Bunny_sample.stl'
        # print(self.vtk_widget.ren.GetBackgroundAlpha(), self.vtk_widget.ren.GetBackground2())
        self.vtk_widget.add_polydata(filename)
        print(self.vtk_widget.__dict__)


def test_main2():

    app = QtWidgets.QApplication(sys.argv)
    # app.w

    window = MainWindow()
    window.show()
    for k, v in window.vtk_widget.__dict__.items():
        print(k, v)
    app.exec_()


if __name__=='__main__':
    # test_main()
    test_main2()