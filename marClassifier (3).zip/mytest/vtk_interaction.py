from packaging import version
import vtk
vtk_version = vtk.vtkVersion().GetVTKVersion()
if version.parse(vtk_version) > version.parse('9.0.0'):
    import vtkmodules.all as vtk
    from vtkmodules.util import numpy_support
else:
    from vtk.util import numpy_support

NONE = -1
ROTATE = 0
ZOOM = 2
PAN = 2

LEFT = 0
RIGHT = 1
MIDDLE = 2

DOWN = 0
UP = 1

class MyInteractorStyle(vtk.vtkInteractorStyleTrackballCamera):

    def __init__(self, parent=None):
        super(MyInteractorStyle, self).__init__()

        """
        vtk default style
        left - rotate
        middle - up & down - pan
        middel-wheel - zoom                
        right - zoom &
        """

        self.parent = parent

        self.event_state = {
            LEFT: NONE,
            RIGHT: ROTATE,
            MIDDLE: ZOOM
        }



        self.vtk_origin_event = {
            PAN: [
                self.OnMiddleButtonDown,
                self.OnMiddleButtonUp
            ],

            ROTATE: [
                self.OnLeftButtonDown,
                self.OnLeftButtonUp,
            ],

            ZOOM: [
                self.OnMouseWheelBackward,
                self.OnMouseWheelForward,
                self.OnRightButtonDown,
                self.OnRightButtonUp
            ]
        }

        self.AddObserver("LeftButtonPressEvent", self.left_button_press) #마우스 왼쪽버튼 프레스 이벤트 핸들러 설정
        self.AddObserver("LeftButtonReleaseEvent", self.left_button_release) #마우스 왼쪽버튼 릴리즈 이벤트 핸들러 설정
        self.AddObserver("MiddleButtonPressEvent", self.middle_button_press) #마우스 가운데버튼 프레스 이벤트 핸들러 설정
        self.AddObserver("MiddleButtonReleaseEvent", self.middle_button_release) #마우스 가운데버튼 릴리즈 이벤트 핸들러 설정
        self.AddObserver("MouseWheelForwardEvent", self.wheel_forward)
        self.AddObserver("MouseWheelBackwardEvent", self.wheel_backward)
        self.AddObserver("MouseMoveEvent", self.mouse_moved)
        self.AddObserver("RightButtonPressEvent", self.right_button_press) #마우스 오른쪽버튼 프레스 이벤트 핸들러 설정
        self.AddObserver("RightButtonReleaseEvent", self.right_button_release) #마우스 오른쪽버튼 릴리즈 이벤트 핸들러 설정

    def mouse_moved(self, obj, event):

        self.OnMouseMove()

        if self.parent and hasattr(self.parent, 'dispatch_event'):
            self.parent.dispatch_event(obj, event)
            # self.parent.mouse_move(obj, event)

    def wheel_forward(self, obj, event):
        self.OnMouseWheelForward()

    def wheel_backward(self, obj, event):
        self.OnMouseWheelBackward()
        pass


    def left_button_press(self, obj, event):

        mode = self.event_state[LEFT]
        if mode in self.vtk_origin_event:
            self.vtk_origin_event[mode][DOWN]()

        if self.parent:
            self.parent.dispatch_event(obj, event)

            # self.parent.left_mouse_down(obj, event)

    def left_button_release(self, obj, event):

        mode = self.event_state[LEFT]
        if mode in self.vtk_origin_event:
            self.vtk_origin_event[mode][DOWN]()

        if self.parent:
            self.parent.update_contour_widget_property()
            self.parent.dispatch_event(obj, event)

    def middle_button_press(self, object, event):
        self.OnMiddleButtonDown()
        return

    def middle_button_release(self, object, event):
        self.OnMiddleButtonUp()
        return

    def right_button_press(self, object, event):
        mode = self.event_state[RIGHT]
        if mode in self.vtk_origin_event:
            self.vtk_origin_event[mode][DOWN]()
        self.OnLeftButtonDown()

    def right_button_release(self, object, event):
        self.OnLeftButtonUp()
        mode = self.event_state[RIGHT]
        if mode in self.vtk_origin_event:
            self.vtk_origin_event[mode][UP]()
