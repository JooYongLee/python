import vtk
from typing import List, Tuple, Dict
from packaging import version
vtk_version = vtk.vtkVersion().GetVTKVersion()
if version.parse(vtk_version) > version.parse('9.0.0'):
    import vtkmodules.all as vtk
    from vtkmodules.util import numpy_support
    from vtkmodules.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor
else:
    from vtk.util import numpy_support
    from vtk.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor


class MouseCommand(object):
    def __init__(self, renderer:vtk.vtkRenderer):
        # super(MouseCommand, self).__init__()
        self.renderer = renderer
        self.renderer.GetRenderWindow()
        renwin = vtk.vtkRenderWindow()
        renwin.GetInteractor()

    def init(self, target_actor:vtk.vtkActor):
        pass

    def ren_win(self)->vtk.vtkRenderWindow:
        return self.renderer.GetRenderWindow()

    def ren_interactor(self)->vtk.vtkRenderWindowInteractor:
        return self.renderer.GetRenderWindow().GetInteractor()

    # def intersections(self):
    def get_pick(self)->Tuple[List[float], List[float], List[vtk.vtkActor]]:
        picker = vtk.vtkCellPicker()
        # volumePicker로 하니깐 부정확함?

        x, y = self.ren_interactor().GetEventPosition()
        picker.Pick(x, y, 0, self.renderer)
        # picker.PickProp(x, y, self.renderer)

        picked_obj = [act for act in picker.GetActors()]
        # print('pick obj#', len(picked_obj), picked_obj)

        # list of intersection
        vtk_points = picker.GetPickedPositions()
        picked_poses = numpy_support.vtk_to_numpy(vtk_points.GetData())
        normal = picker.GetPickNormal()

        # print('pose list', picked_poses, picked_poses.shape)
        return picked_poses, normal, picked_obj

    def left_mouse_down(self, obj, event):
        raise NotImplementedError

    def left_mouse_up(self, obj, event):
        raise NotImplementedError

    def mouse_moved(self, obj, event):
        raise NotImplementedError

    def release(self):
        raise NotImplementedError


class VtkEventDispatcher(object):
    def __init__(self):
        pass

        self._commands = dict()  # type:Dict[int, MouseCommand]
        # self._commands[LANDMARK_MODE] = LandmarkCommand(self.ren)
        # self._commands[CONTOUR_MODE] = ContourCommand(self.ren)

    def current_mode(self)->int:
        raise ValueError
        # text = self.mode_button.text()
        # founded = [key for key, value in mode_table_qtname.items() if value == text]
        # if founded:
        #     return founded[0]
        # else:
        #     raise ValueError('not defined mode')

    def add_command(self, cmd_index:int, cmd:MouseCommand):
        self._commands[cmd_index] = cmd

    def dispatch_event(self, obj, event):
        # print(event, type(event))
        # 다음 event name은 vtk event명. vtk.vtkRenderWindowInteractor 참고
        container = {
            'MouseMoveEvent': self.mouse_move,
            'LeftButtonPressEvent': self.left_mouse_down,
            'LeftButtonReleaseEvent': self.left_mouse_up
        }

        # dispatch
        if event in container:
            container[event](obj, event)

    def left_mouse_up(self, obj, event):
        if self.command():
            self.command().left_mouse_up(obj, event)

            self.save_document()

    def left_mouse_down(self, obj, event):
        if self.command():
            self.command().left_mouse_down(obj, event)

    def mouse_move(self, obj, event):
        if self.command():
            self.command().mouse_moved(obj, event)

    def prev_command(self)->MouseCommand:
        mode = self.previous_mode
        return self._commands.get(mode, None)

    def command(self, mode:int=-1)->MouseCommand:
        if mode <= 0:
            mode = self.current_mode()
            return self._commands.get(mode, None)
        else:
            assert mode in self._commands, "not defined command in list"
            return self._commands[mode]
        # if mode in self._commands:
        #     return self._commands[mode]


